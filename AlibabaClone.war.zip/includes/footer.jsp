<footer>
    <!-- ROW 1: Footer Columns -->
    <div class="footer-row-1">
        <div class="footer-col">
            <h4><i class="fa-solid fa-headset"></i> Get support</h4>
            <a href="#"><i class="fa-regular fa-circle-question"></i> Help Center</a>
            <a href="#"><i class="fa-solid fa-comments"></i> Live chat</a>
            <a href="#"><i class="fa-solid fa-box"></i> Check order status</a>
            <a href="#"><i class="fa-solid fa-rotate-left"></i> Refunds</a>
            <a href="#"><i class="fa-solid fa-flag"></i> Report abuse</a>
        </div>
        <div class="footer-col">
            <h4><i class="fa-solid fa-lock"></i> Payments &amp; protection</h4>
            <a href="#"><i class="fa-solid fa-credit-card"></i> Safe and easy payments</a>
            <a href="#"><i class="fa-solid fa-shield"></i> Money-back policy</a>
            <a href="#"><i class="fa-solid fa-truck-fast"></i> On-time shipping</a>
            <a href="#"><i class="fa-solid fa-star"></i> After-sales protections</a>
            <a href="#"><i class="fa-solid fa-magnifying-glass"></i> Product monitoring</a>
        </div>
        <div class="footer-col">
            <h4><i class="fa-solid fa-store"></i> Source on Alibaba.com</h4>
            <a href="${pageContext.request.contextPath}/views/rfq.jsp">
                <i class="fa-solid fa-file-invoice"></i> Request for Quotation
            </a>
            <a href="#"><i class="fa-solid fa-users"></i> Membership program</a>
            <a href="#"><i class="fa-solid fa-percent"></i> Sales tax and VAT</a>
            <a href="#"><i class="fa-regular fa-newspaper"></i> Alibaba.com Reads</a>
        </div>
        <div class="footer-col">
            <h4><i class="fa-solid fa-tag"></i> Sell on Alibaba.com</h4>
            <a href="#"><i class="fa-solid fa-shop"></i> Start selling</a>
            <a href="#"><i class="fa-solid fa-gauge-high"></i> Seller Central</a>
            <a href="#"><i class="fa-solid fa-certificate"></i> Become a Verified Supplier</a>
            <a href="#"><i class="fa-solid fa-handshake"></i> Partnerships</a>
            <a href="#"><i class="fa-solid fa-mobile-screen"></i> App for suppliers</a>
        </div>
        <div class="footer-col">
            <h4><i class="fa-solid fa-building"></i> Get to know us</h4>
            <a href="#"><i class="fa-solid fa-circle-info"></i> About Alibaba.com</a>
            <a href="#"><i class="fa-solid fa-leaf"></i> Corporate responsibility</a>
            <a href="#"><i class="fa-regular fa-newspaper"></i> News center</a>
            <a href="#"><i class="fa-solid fa-briefcase"></i> Careers</a>

            <!-- Stay Connected -->
            <div class="social-icons-row">
                <h4><i class="fa-solid fa-share-nodes"></i> Stay Connected</h4>
                <div class="social-icons">
                    <a href="#" class="social-icon" title="Facebook">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>
                    <a href="#" class="social-icon" title="LinkedIn">
                        <i class="fa-brands fa-linkedin-in"></i>
                    </a>
                    <a href="#" class="social-icon" title="X / Twitter">
                        <i class="fa-brands fa-x-twitter"></i>
                    </a>
                    <a href="#" class="social-icon" title="Instagram">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                    <a href="#" class="social-icon" title="YouTube">
                        <i class="fa-brands fa-youtube"></i>
                    </a>
                    <a href="#" class="social-icon" title="TikTok">
                        <i class="fa-brands fa-tiktok"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- ROW 2: Trust & Payment Badges -->
    <div class="footer-row-2">
        <div class="trust-badges">
            <span class="pill-badge"><i class="fa-solid fa-id-card"></i> ID Check</span>
            <span class="pill-badge"><i class="fa-solid fa-shield-halved"></i> PCI</span>
            <span class="pill-badge"><i class="fa-solid fa-check-double"></i> VeriSign</span>
            <span class="pill-badge"><i class="fa-solid fa-lock"></i> SSL Secure</span>
        </div>
        <div class="pay-badges">
            <span class="pill-badge">VISA</span>
            <span class="pill-badge">Mastercard</span>
            <span class="pill-badge">AMEX</span>
            <span class="pill-badge">Stripe</span>
            <span class="pill-badge">UnionPay</span>
            <span class="pill-badge">PayPal</span>
            <span class="pill-badge"><i class="fa-brands fa-apple"></i> Pay</span>
            <span class="pill-badge"><i class="fa-brands fa-google-pay"></i></span>
        </div>
    </div>

    <!-- ROW 3: App Download -->
    <div class="footer-row-3">
        <div class="footer-row-3-left">
            <i class="fa-brands fa-chrome"></i>
            Add <a href="#" class="footer-accent-link">Alibaba Lens</a> to Chrome
        </div>
        <div class="footer-row-3-right">
            <span class="footer-app-text"><i class="fa-solid fa-mobile-screen-button"></i> Trade on the go</span>
            <a href="#" class="app-badge">
                <i class="fa-brands fa-apple"></i> App Store
            </a>
            <a href="#" class="app-badge">
                <i class="fa-brands fa-google-play"></i> Google Play
            </a>
        </div>
    </div>

    <!-- ROW 4: Ecosystem Links -->
    <div class="footer-row-4">
        AliExpress &nbsp;&bull;&nbsp; 1688.com &nbsp;&bull;&nbsp; Tmall &nbsp;&bull;&nbsp;
        Taobao &nbsp;&bull;&nbsp; Alipay &nbsp;&bull;&nbsp; Lazada &nbsp;&bull;&nbsp;
        Trendyol &nbsp;&bull;&nbsp; Europages
    </div>

    <!-- ROW 5: Legal -->
    <div class="footer-row-5">
        Privacy Policy &middot; Terms of Use &middot; Legal Notice &middot; Integrity Compliance
        &middot; Product Listing Policy &middot; Intellectual Property Protection<br>
        &copy; 1999&ndash;2026 Alibaba.com. All rights reserved.
    </div>
</footer>
</body>
</html>
