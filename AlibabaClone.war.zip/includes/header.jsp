<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alibaba.com &ndash; Global B2B Marketplace</title>

    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/main.css?v=2">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/navbar.css?v=2">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/cards.css?v=2">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/badges.css?v=2">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/sidebar.css?v=2">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/footer.css?v=2">

    <!-- Scripts (deferred) -->
    <script src="${pageContext.request.contextPath}/js/tabs.js" defer></script>
    <script src="${pageContext.request.contextPath}/js/search.js" defer></script>
    <script src="${pageContext.request.contextPath}/js/cart.js" defer></script>
    <script src="${pageContext.request.contextPath}/js/navbar.js" defer></script>
</head>
<body>

<header>
    <!-- BAR 1: Utility Bar (Dark top strip) -->
    <div class="utility-bar">
        <div class="utility-left">
            <i class="fa-solid fa-location-dot"></i> Deliver to: <strong>India</strong>
        </div>
        <div class="utility-right">
            <span><i class="fa-solid fa-globe"></i> English &ndash; USD</span>
            <a href="${pageContext.request.contextPath}/cart">
                <i class="fa-solid fa-cart-shopping"></i> Cart
            </a>
            <c:choose>
                <c:when test="${not empty sessionScope.loggedInUser}">
                    <!-- User is logged in -->
                    <a href="${pageContext.request.contextPath}/views/account.jsp">
                        <i class="fa-regular fa-user"></i> ${sessionScope.loggedInUser.username}
                    </a>
                    <a href="${pageContext.request.contextPath}/user?action=logout" style="color:#FF6A00;">
                        <i class="fa-solid fa-sign-out-alt"></i> Sign out
                    </a>
                </c:when>
                <c:otherwise>
                    <!-- User not logged in -->
                    <a href="${pageContext.request.contextPath}/views/login.jsp">
                        <i class="fa-regular fa-user"></i> Account
                    </a>
                    <a href="${pageContext.request.contextPath}/views/register.jsp" class="utility-cta">
                        Join Free
                    </a>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <!-- BAR 2: Main Navbar -->
    <div class="main-navbar">
        <!-- Logo -->
        <a href="${pageContext.request.contextPath}/" class="brand-logo">
            <span class="logo-ali">ali</span><span class="logo-baba">baba</span><span class="logo-dot">.com</span>
        </a>

        <!-- Left Nav Links -->
        <div class="nav-left">
            <span class="hamburger" id="hamburgerMenu">
                <i class="fa-solid fa-bars"></i>&nbsp; All categories
            </span>
            <a href="#"><i class="fa-solid fa-certificate"></i> Verified</a>
            <a href="#"><i class="fa-solid fa-shield-halved"></i> Order protection</a>
        </div>

        <!-- Right Nav Links -->
        <div class="nav-right">
            <a href="#">Trade assurance</a>
            <a href="#">Buyer Central</a>
            <c:choose>
                <c:when test="${not empty sessionScope.loggedInUser}">
                    <!-- User is logged in -->
                    <span class="nav-user-info">
                        <i class="fa-regular fa-user"></i> ${sessionScope.loggedInUser.username}
                    </span>
                    <a href="${pageContext.request.contextPath}/user?action=logout" class="nav-signin-btn" style="background:#FF6A00;">
                        <i class="fa-solid fa-sign-out-alt"></i> Sign out
                    </a>
                </c:when>
                <c:otherwise>
                    <!-- User not logged in -->
                    <a href="${pageContext.request.contextPath}/views/login.jsp" class="nav-signin-btn">
                        <i class="fa-regular fa-user"></i> Sign in
                    </a>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <!-- BAR 3: Search -->
    <div class="search-section">
        <div class="search-tabs">
            <div class="search-tab"><i class="fa-solid fa-wand-magic-sparkles"></i> AI Mode</div>
            <div class="search-tab active"><i class="fa-solid fa-box-open"></i> Products</div>
            <div class="search-tab"><i class="fa-solid fa-industry"></i> Manufacturers</div>
            <div class="search-tab"><i class="fa-solid fa-globe"></i> Worldwide</div>
        </div>
        <div class="search-card">
            <div class="search-input-row">
                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                <input type="text" id="mainSearchInput" placeholder="Search products, suppliers, categories..." autocomplete="off">
                <div class="search-divider"></div>
                <button class="search-btn" id="searchSubmitBtn">Search</button>
            <div class="search-dropdown" id="searchDropdown"></div>
        </div>
        <div class="image-search-row">
            <i class="fa-solid fa-camera"></i> Search by image
            &nbsp;<span class="image-search-sep">|</span>&nbsp;
            <i class="fa-solid fa-microphone"></i> Voice search
        </div>
    </div>
</header>

<!-- Mega Menu Overlay -->
<div class="mega-menu" id="megaMenu">
    <div class="mega-menu-content">
        <h3><i class="fa-solid fa-grip"></i> All Categories</h3>
    </div>
</div>
