package com.alibaba.model;

import java.sql.Timestamp;

public class Product {
    private int id;
    private int supplierId;
    private int categoryId;
    private String title;
    private String description;
    private int minOrderQty;
    private String unit;
    private double priceMin;
    private double priceMax;
    private Double originalPrice;
    private int discountPercent;
    private String imageUrl;
    private boolean readyToShip;
    private Integer dispatchDays;
    private double rating;
    private int reviewCount;
    private int soldCount;
    private boolean topDeal;
    private boolean newArrival;
    private boolean topRanking;
    private int listedDaysAgo;
    private String badgeText;
    private Timestamp createdAt;

    // Transient fields for View
    private Supplier supplier;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }

    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getMinOrderQty() { return minOrderQty; }
    public void setMinOrderQty(int minOrderQty) { this.minOrderQty = minOrderQty; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public double getPriceMin() { return priceMin; }
    public void setPriceMin(double priceMin) { this.priceMin = priceMin; }

    public double getPriceMax() { return priceMax; }
    public void setPriceMax(double priceMax) { this.priceMax = priceMax; }

    public Double getOriginalPrice() { return originalPrice; }
    public void setOriginalPrice(Double originalPrice) { this.originalPrice = originalPrice; }

    public int getDiscountPercent() { return discountPercent; }
    public void setDiscountPercent(int discountPercent) { this.discountPercent = discountPercent; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public boolean isReadyToShip() { return readyToShip; }
    public void setReadyToShip(boolean readyToShip) { this.readyToShip = readyToShip; }

    public Integer getDispatchDays() { return dispatchDays; }
    public void setDispatchDays(Integer dispatchDays) { this.dispatchDays = dispatchDays; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    public int getReviewCount() { return reviewCount; }
    public void setReviewCount(int reviewCount) { this.reviewCount = reviewCount; }

    public int getSoldCount() { return soldCount; }
    public void setSoldCount(int soldCount) { this.soldCount = soldCount; }

    public boolean isTopDeal() { return topDeal; }
    public void setTopDeal(boolean topDeal) { this.topDeal = topDeal; }

    public boolean isNewArrival() { return newArrival; }
    public void setNewArrival(boolean newArrival) { this.newArrival = newArrival; }

    public boolean isTopRanking() { return topRanking; }
    public void setTopRanking(boolean topRanking) { this.topRanking = topRanking; }

    public int getListedDaysAgo() { return listedDaysAgo; }
    public void setListedDaysAgo(int listedDaysAgo) { this.listedDaysAgo = listedDaysAgo; }

    public String getBadgeText() { return badgeText; }
    public void setBadgeText(String badgeText) { this.badgeText = badgeText; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public Supplier getSupplier() { return supplier; }
    public void setSupplier(Supplier supplier) { this.supplier = supplier; }

    @Override
    public String toString() {
        return "Product{" + "id=" + id + ", title='" + title + '\'' + '}';
    }
}
