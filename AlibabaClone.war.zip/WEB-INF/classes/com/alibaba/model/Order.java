package com.alibaba.model;

import java.sql.Timestamp;
import java.util.List;

public class Order {
    private String orderNumber;
    private Timestamp placedAt;
    private double total;
    private List<CartItem> items;

    public String getOrderNumber() { return orderNumber; }
    public void setOrderNumber(String orderNumber) { this.orderNumber = orderNumber; }

    public Timestamp getPlacedAt() { return placedAt; }
    public void setPlacedAt(Timestamp placedAt) { this.placedAt = placedAt; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public List<CartItem> getItems() { return items; }
    public void setItems(List<CartItem> items) { this.items = items; }
}
