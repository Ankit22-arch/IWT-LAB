package com.alibaba.model;

import java.sql.Timestamp;

public class Supplier {
    private int id;
    private int userId;
    private String companyName;
    private String country;
    private String countryCode;
    private int yearsOnPlatform;
    private boolean verified;
    private boolean tradeAssurance;
    private int responseRate;
    private String logoUrl;
    private String description;
    private Timestamp createdAt;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getCountryCode() { return countryCode; }
    public void setCountryCode(String countryCode) { this.countryCode = countryCode; }

    public int getYearsOnPlatform() { return yearsOnPlatform; }
    public void setYearsOnPlatform(int yearsOnPlatform) { this.yearsOnPlatform = yearsOnPlatform; }

    public boolean isVerified() { return verified; }
    public void setVerified(boolean verified) { this.verified = verified; }

    public boolean isTradeAssurance() { return tradeAssurance; }
    public void setTradeAssurance(boolean tradeAssurance) { this.tradeAssurance = tradeAssurance; }

    public int getResponseRate() { return responseRate; }
    public void setResponseRate(int responseRate) { this.responseRate = responseRate; }

    public String getLogoUrl() { return logoUrl; }
    public void setLogoUrl(String logoUrl) { this.logoUrl = logoUrl; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "Supplier{" + "id=" + id + ", companyName='" + companyName + '\'' + '}';
    }
}
