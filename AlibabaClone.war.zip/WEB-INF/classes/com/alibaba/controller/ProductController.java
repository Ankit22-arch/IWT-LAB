package com.alibaba.controller;

import com.alibaba.dao.CategoryDAO;
import com.alibaba.dao.ProductDAO;
import com.alibaba.dao.UserDAO;
import com.alibaba.model.Category;
import com.alibaba.model.Product;
import com.alibaba.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/product")
public class ProductController extends HttpServlet {
    private ProductDAO productDAO;
    private CategoryDAO categoryDAO;

    @Override
    public void init() throws ServletException {
        productDAO = new ProductDAO();
        categoryDAO = new CategoryDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        
        if ("search".equals(type)) {
            // AJAX Search JSON response
            String q = request.getParameter("q");
            List<Product> results = productDAO.searchProducts(q, 0, "best_match", false, false, 1, 8);
            
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < results.size(); i++) {
                Product p = results.get(i);
                json.append("{")
                    .append("\"id\":").append(p.getId()).append(",")
                    .append("\"title\":\"").append(p.getTitle().replace("\"", "\\\"")).append("\",")
                    .append("\"price_min\":").append(p.getPriceMin()).append(",")
                    .append("\"image_url\":\"").append(p.getImageUrl()).append("\"")
                    .append("}");
                if (i < results.size() - 1) json.append(",");
            }
            json.append("]");
            response.getWriter().write(json.toString());
            
        } else if ("detail".equals(type)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Product product = productDAO.getProductById(id);
            request.setAttribute("product", product);
            request.getRequestDispatcher("/views/productDetail.jsp").forward(request, response);
            
        } else if ("category".equals(type)) {
            int catId = Integer.parseInt(request.getParameter("id"));
            List<Product> products = productDAO.getProductsByCategory(catId, 20);
            request.setAttribute("products", products);
            request.getRequestDispatcher("/views/categoryPage.jsp").forward(request, response);
            
        } else if ("results".equals(type)) {
            String q = request.getParameter("q");
            String sortBy = request.getParameter("sortBy");
            if (sortBy == null) sortBy = "best_match";
            
            int page = 1;
            if (request.getParameter("page") != null) {
                page = Integer.parseInt(request.getParameter("page"));
            }
            
            List<Product> products = productDAO.searchProducts(q, 0, sortBy, false, false, page, 24);
            request.setAttribute("products", products);
            request.setAttribute("keyword", q);
            request.getRequestDispatcher("/views/searchResults.jsp").forward(request, response);
            
        } else {
            // Default -> index.jsp
            List<Category> categories = categoryDAO.getAllTopLevelCategories();
            for (Category c : categories) {
                c.setSubCategories(categoryDAO.getSubCategories(c.getId()));
            }
            
            request.setAttribute("categories", categories);
            request.setAttribute("recommended", productDAO.getRecommendedProducts(2));
            request.setAttribute("fastCustom", productDAO.getFastCustomizationProducts(4));
            request.setAttribute("topDeals", productDAO.getTopDealProducts(6));
            request.setAttribute("newArrivals", productDAO.getNewArrivalProducts(4));
            request.setAttribute("topRanking", productDAO.getTopRankingProducts(4));
            request.setAttribute("tailored", productDAO.getRecommendedProducts(8));
            
            request.getRequestDispatcher("/views/index.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("rfq".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("loggedInUser") == null) {
                response.setContentType("application/json");
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("{\"status\":\"error\"}");
                return;
            }
            
            User user = (User) session.getAttribute("loggedInUser");
            String productName = request.getParameter("product_name");
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            String unit = request.getParameter("unit");
            String description = request.getParameter("description");
            
            String query = "INSERT INTO rfq (user_id, product_name, quantity, unit, description) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = com.alibaba.util.DBConnection.getInstance().getConnection();
                 PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setInt(1, user.getId());
                ps.setString(2, productName);
                ps.setInt(3, quantity);
                ps.setString(4, unit);
                ps.setString(5, description);
                ps.executeUpdate();
                
                response.setContentType("application/json");
                response.getWriter().write("{\"status\":\"success\"}");
            } catch (SQLException e) {
                e.printStackTrace();
                response.setContentType("application/json");
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"status\":\"error\"}");
            }
        }
    }
}
