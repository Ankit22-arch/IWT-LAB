package com.alibaba.controller;

import com.alibaba.dao.SupplierDAO;
import com.alibaba.dao.ProductDAO;
import com.alibaba.model.Supplier;
import com.alibaba.model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/supplier")
public class SupplierController extends HttpServlet {
    private SupplierDAO supplierDAO;
    private ProductDAO productDAO;

    @Override
    public void init() throws ServletException {
        supplierDAO = new SupplierDAO();
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam != null && !idParam.isEmpty()) {
            int id = Integer.parseInt(idParam);
            Supplier supplier = supplierDAO.getSupplierById(id);
            List<Product> products = supplierDAO.getProductsBySupplier(id);

            request.setAttribute("supplier", supplier);
            request.setAttribute("products", products);
            request.getRequestDispatcher("/views/supplierProfile.jsp").forward(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/product");
        }
    }
}
