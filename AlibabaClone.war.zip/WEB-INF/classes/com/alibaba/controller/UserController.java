package com.alibaba.controller;

import com.alibaba.dao.UserDAO;
import com.alibaba.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/user")
public class UserController extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("logout".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            response.sendRedirect(request.getContextPath() + "/product");
        } else {
            response.sendRedirect(request.getContextPath() + "/product");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("register".equals(action)) {
            User user = new User();
            user.setUsername(request.getParameter("username"));
            user.setEmail(request.getParameter("email"));
            // For simplicity, skip proper bcrypt here and use simple pass just as placeholder, but ideally use BCrypt
            user.setPasswordHash(request.getParameter("password")); // Please implement BCrypt
            user.setRole(request.getParameter("role"));
            user.setCountryCode("IN"); // Default

            if (userDAO.getUserByEmail(user.getEmail()) != null) {
                response.sendRedirect(request.getContextPath() + "/views/register.jsp?error=exists");
            } else if (userDAO.registerUser(user)) {
                response.sendRedirect(request.getContextPath() + "/views/login.jsp?success=true");
            } else {
                response.sendRedirect(request.getContextPath() + "/views/register.jsp?error=true");
            }
        } else if ("login".equals(action)) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            User user = userDAO.getUserByEmail(email);
            // Ideally bcrypt.checkpw
            if (user != null && password.equals(user.getPasswordHash())) {
                HttpSession session = request.getSession();
                session.setAttribute("loggedInUser", user);
                response.sendRedirect(request.getContextPath() + "/product");
            } else {
                response.sendRedirect(request.getContextPath() + "/views/login.jsp?error=true");
            }
        }
    }
}
