package com.alibaba.controller;

import com.alibaba.dao.CartDAO;
import com.alibaba.dao.ProductDAO;
import com.alibaba.model.CartItem;
import com.alibaba.model.Product;
import com.alibaba.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/cart")
public class CartController extends HttpServlet {
    private CartDAO cartDAO;
    private ProductDAO productDAO;

    @Override
    public void init() throws ServletException {
        cartDAO = new CartDAO();
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
            return;
        }

        User user = (User) session.getAttribute("loggedInUser");
        List<CartItem> cartItems = cartDAO.getCartItems(user.getId());
        request.setAttribute("cartItems", cartItems);
        request.getRequestDispatcher("/views/cart.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if (session == null || session.getAttribute("loggedInUser") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"status\":\"error\",\"message\":\"Unauthorized\"}");
            return;
        }

        User user = (User) session.getAttribute("loggedInUser");
        String action = request.getParameter("action");
        int productId = Integer.parseInt(request.getParameter("productId"));

        try {
            if ("add".equals(action)) {
                // Validate that the product doesn't belong to the logged-in user
                Product product = productDAO.getProductById(productId);
                if (product != null && product.getSupplierId() > 0) {
                    // Get supplier info
                    if (product.getSupplier() != null && product.getSupplier().getUserId() == user.getId()) {
                        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                        response.getWriter().write("{\"status\":\"error\",\"message\":\"You cannot add your own products to cart\"}");
                        return;
                    }
                }
                
                int qty = Integer.parseInt(request.getParameter("qty"));
                boolean success = cartDAO.addToCart(user.getId(), productId, qty);
                response.getWriter().write("{\"status\":\"" + (success ? "success" : "error") + "\"}");
            } else if ("remove".equals(action)) {
                boolean success = cartDAO.removeFromCart(user.getId(), productId);
                response.getWriter().write("{\"status\":\"" + (success ? "success" : "error") + "\"}");
            } else if ("update_qty".equals(action)) {
                int qty = Integer.parseInt(request.getParameter("qty"));
                boolean success = cartDAO.updateCartQuantity(user.getId(), productId, qty);
                response.getWriter().write("{\"status\":\"" + (success ? "success" : "error") + "\"}");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}");
        }
    }
}
