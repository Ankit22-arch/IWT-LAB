package com.alibaba.controller;

import com.alibaba.dao.CartDAO;
import com.alibaba.model.CartItem;
import com.alibaba.model.Order;
import com.alibaba.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/checkout")
public class CheckoutController extends HttpServlet {
    private CartDAO cartDAO;

    @Override
    public void init() throws ServletException {
        cartDAO = new CartDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/cart");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
            return;
        }

        User user = (User) session.getAttribute("loggedInUser");
        List<CartItem> cartItems = cartDAO.getCartItems(user.getId());
        if (cartItems.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        double total = 0.0;
        for (CartItem item : cartItems) {
            if (item.getProduct() != null) {
                total += item.getProduct().getPriceMin() * item.getQuantity();
            }
        }

        Order order = new Order();
        order.setOrderNumber("ORD-" + System.currentTimeMillis() + "-" + user.getId());
        order.setPlacedAt(new Timestamp(System.currentTimeMillis()));
        order.setTotal(total);
        order.setItems(cartItems);

        @SuppressWarnings("unchecked")
        List<Order> orderHistory = (List<Order>) session.getAttribute("orderHistory");
        if (orderHistory == null) {
            orderHistory = new ArrayList<>();
        }
        orderHistory.add(0, order);
        session.setAttribute("orderHistory", orderHistory);

        cartDAO.clearCart(user.getId());

        request.setAttribute("order", order);
        request.getRequestDispatcher("/views/orderSuccess.jsp").forward(request, response);
    }
}
