package com.alibaba.dao;

import com.alibaba.model.Product;
import com.alibaba.model.Supplier;
import com.alibaba.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProductDAO {
    private static final Logger LOGGER = Logger.getLogger(ProductDAO.class.getName());

    public List<Product> searchProducts(String keyword, int categoryId, String sortBy, boolean readyToShip, boolean verifiedOnly, int page, int pageSize) {
        List<Product> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT p.*, " +
            "s.id as s_id, s.user_id as s_user_id, s.company_name as s_company_name, s.country as s_country, s.country_code as s_country_code, s.years_on_platform as s_years_on_platform, s.verified as s_verified, s.trade_assurance as s_trade_assurance " +
            "FROM products p " +
            "JOIN suppliers s ON p.supplier_id = s.id WHERE 1=1 ");

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append("AND (p.title ILIKE ? OR p.description ILIKE ?) ");
        }
        if (categoryId > 0) {
            sql.append("AND p.category_id = ? ");
        }
        if (readyToShip) {
            sql.append("AND p.ready_to_ship = TRUE ");
        }
        if (verifiedOnly) {
            sql.append("AND s.verified = TRUE ");
        }

        switch (sortBy) {
            case "price_asc" -> sql.append("ORDER BY p.price_min ASC ");
            case "price_desc" -> sql.append("ORDER BY p.price_min DESC ");
            case "newest" -> sql.append("ORDER BY p.created_at DESC ");
            case "most_sold" -> sql.append("ORDER BY p.sold_count DESC ");
            default -> sql.append("ORDER BY p.id ASC "); // best_match
        }

        sql.append("LIMIT ? OFFSET ?");

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int paramIndex = 1;
            if (keyword != null && !keyword.trim().isEmpty()) {
                ps.setString(paramIndex++, "%" + keyword + "%");
                ps.setString(paramIndex++, "%" + keyword + "%");
            }
            if (categoryId > 0) {
                ps.setInt(paramIndex++, categoryId);
            }
            ps.setInt(paramIndex++, pageSize);
            ps.setInt(paramIndex++, (page - 1) * pageSize);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product p = extractProduct(rs);
                    p.setSupplier(extractSupplierFromJoin(rs));
                    list.add(p);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error searching products", e);
        }
        return list;
    }

    public Product getProductById(int id) {
        String sql = "SELECT p.*, " +
            "s.id as s_id, s.user_id as s_user_id, s.company_name as s_company_name, s.country as s_country, s.country_code as s_country_code, s.years_on_platform as s_years_on_platform, s.verified as s_verified, s.trade_assurance as s_trade_assurance " +
            "FROM products p JOIN suppliers s ON p.supplier_id = s.id WHERE p.id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Product p = extractProduct(rs);
                    p.setSupplier(extractSupplierFromJoin(rs));
                    return p;
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting product by id", e);
        }
        return null;
    }

    public List<Product> getProductsByCategory(int categoryId, int limit) {
        return getListByCondition("category_id = ?", categoryId, limit);
    }

    public List<Product> getTopDealProducts(int limit) {
        return getListByCondition("is_top_deal = TRUE", null, limit);
    }

    public List<Product> getNewArrivalProducts(int limit) {
        return getListByCondition("is_new_arrival = TRUE", null, limit);
    }

    public List<Product> getTopRankingProducts(int limit) {
        return getListByCondition("is_top_ranking = TRUE", null, limit);
    }

    public List<Product> getRecommendedProducts(int limit) {
        return getListByCondition("1=1 ORDER BY RANDOM()", null, limit);
    }

    public List<Product> getFastCustomizationProducts(int limit) {
        return getListByCondition("ready_to_ship = TRUE AND dispatch_days <= 14", null, limit);
    }

    private List<Product> getListByCondition(String condition, Integer param, int limit) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, " +
            "s.id as s_id, s.user_id as s_user_id, s.company_name as s_company_name, s.country as s_country, s.country_code as s_country_code, s.years_on_platform as s_years_on_platform, s.verified as s_verified, s.trade_assurance as s_trade_assurance " +
            "FROM products p JOIN suppliers s ON p.supplier_id = s.id WHERE " + condition + " LIMIT ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            int idx = 1;
            if (param != null) {
                ps.setInt(idx++, param);
            }
            ps.setInt(idx, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product p = extractProduct(rs);
                    p.setSupplier(extractSupplierFromJoin(rs));
                    list.add(p);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting list by condition", e);
        }
        return list;
    }

    public Product extractProduct(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setId(rs.getInt("id"));
        p.setSupplierId(rs.getInt("supplier_id"));
        p.setCategoryId(rs.getInt("category_id"));
        p.setTitle(rs.getString("title"));
        p.setDescription(rs.getString("description"));
        p.setMinOrderQty(rs.getInt("min_order_qty"));
        p.setUnit(rs.getString("unit"));
        p.setPriceMin(rs.getDouble("price_min"));
        p.setPriceMax(rs.getDouble("price_max"));
        
        double op = rs.getDouble("original_price");
        if (!rs.wasNull()) p.setOriginalPrice(op);
        
        p.setDiscountPercent(rs.getInt("discount_percent"));
        p.setImageUrl(rs.getString("image_url"));
        p.setReadyToShip(rs.getBoolean("ready_to_ship"));
        p.setDispatchDays(rs.getInt("dispatch_days"));
        p.setRating(rs.getDouble("rating"));
        p.setReviewCount(rs.getInt("review_count"));
        p.setSoldCount(rs.getInt("sold_count"));
        p.setTopDeal(rs.getBoolean("is_top_deal"));
        p.setNewArrival(rs.getBoolean("is_new_arrival"));
        p.setTopRanking(rs.getBoolean("is_top_ranking"));
        p.setListedDaysAgo(rs.getInt("listed_days_ago"));
        p.setBadgeText(rs.getString("badge_text"));
        p.setCreatedAt(rs.getTimestamp("created_at"));
        return p;
    }

    private Supplier extractSupplierFromJoin(ResultSet rs) throws SQLException {
        Supplier s = new Supplier();
        s.setId(rs.getInt("s_id"));
        s.setUserId(rs.getInt("s_user_id"));
        s.setCompanyName(rs.getString("s_company_name"));
        s.setCountry(rs.getString("s_country"));
        s.setCountryCode(rs.getString("s_country_code"));
        s.setYearsOnPlatform(rs.getInt("s_years_on_platform"));
        s.setVerified(rs.getBoolean("s_verified"));
        s.setTradeAssurance(rs.getBoolean("s_trade_assurance"));
        return s;
    }
}
