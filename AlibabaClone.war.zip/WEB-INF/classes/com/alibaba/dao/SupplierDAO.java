package com.alibaba.dao;

import com.alibaba.model.Supplier;
import com.alibaba.model.Product;
import com.alibaba.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SupplierDAO {
    // getSupplierById
    public Supplier getSupplierById(int id) {
        String query = "SELECT * FROM suppliers WHERE id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractSupplier(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // getVerifiedSuppliers
    public List<Supplier> getVerifiedSuppliers(int limit) {
        List<Supplier> list = new ArrayList<>();
        String query = "SELECT * FROM suppliers WHERE verified = TRUE LIMIT ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(extractSupplier(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // getProductsBySupplier
    public List<Product> getProductsBySupplier(int supplierId) {
        ProductDAO pDao = new ProductDAO();
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM products WHERE supplier_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, supplierId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    products.add(pDao.extractProduct(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    private Supplier extractSupplier(ResultSet rs) throws SQLException {
        Supplier s = new Supplier();
        s.setId(rs.getInt("id"));
        s.setUserId(rs.getInt("user_id"));
        s.setCompanyName(rs.getString("company_name"));
        s.setCountry(rs.getString("country"));
        s.setCountryCode(rs.getString("country_code"));
        s.setYearsOnPlatform(rs.getInt("years_on_platform"));
        s.setVerified(rs.getBoolean("verified"));
        s.setTradeAssurance(rs.getBoolean("trade_assurance"));
        s.setResponseRate(rs.getInt("response_rate"));
        s.setLogoUrl(rs.getString("logo_url"));
        s.setDescription(rs.getString("description"));
        s.setCreatedAt(rs.getTimestamp("created_at"));
        return s;
    }
}
