package com.alibaba.dao;

import com.alibaba.model.CartItem;
import com.alibaba.model.Product;
import com.alibaba.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {
    
    public boolean addToCart(int userId, int productId, int qty) {
        String query = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?) " +
                       "ON CONFLICT DO NOTHING"; // Normally handled differently for actual update
        // We do basic insert for now
        String updateIfExist = "UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?";
        String checkExist = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
        
        try (Connection conn = DBConnection.getInstance().getConnection()) {
            boolean exists = false;
            try(PreparedStatement ps1 = conn.prepareStatement(checkExist)) {
                ps1.setInt(1, userId);
                ps1.setInt(2, productId);
                try(ResultSet rs = ps1.executeQuery()) {
                    exists = rs.next();
                }
            }
            if(exists) {
                try(PreparedStatement ps2 = conn.prepareStatement(updateIfExist)) {
                    ps2.setInt(1, qty);
                    ps2.setInt(2, userId);
                    ps2.setInt(3, productId);
                    return ps2.executeUpdate() > 0;
                }
            } else {
                String insert = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
                try(PreparedStatement ps3 = conn.prepareStatement(insert)) {
                    ps3.setInt(1, userId);
                    ps3.setInt(2, productId);
                    ps3.setInt(3, qty);
                    return ps3.executeUpdate() > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean removeFromCart(int userId, int productId) {
        String query = "DELETE FROM cart WHERE user_id = ? AND product_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            ps.setInt(2, productId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateCartQuantity(int userId, int productId, int newQty) {
        String query = "UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, newQty);
            ps.setInt(2, userId);
            ps.setInt(3, productId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<CartItem> getCartItems(int userId) {
        List<CartItem> list = new ArrayList<>();
        String query = "SELECT c.*, p.title, p.price_min, p.image_url FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CartItem c = new CartItem();
                    c.setId(rs.getInt("id"));
                    c.setUserId(rs.getInt("user_id"));
                    c.setProductId(rs.getInt("product_id"));
                    c.setQuantity(rs.getInt("quantity"));
                    c.setAddedAt(rs.getTimestamp("added_at"));
                    
                    Product p = new Product();
                    p.setTitle(rs.getString("title"));
                    p.setPriceMin(rs.getDouble("price_min"));
                    p.setImageUrl(rs.getString("image_url"));
                    c.setProduct(p);
                    
                    list.add(c);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getCartCount(int userId) {
        String query = "SELECT SUM(quantity) FROM cart WHERE user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean clearCart(int userId) {
        String query = "DELETE FROM cart WHERE user_id = ?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
