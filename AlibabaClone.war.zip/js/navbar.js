document.addEventListener("DOMContentLoaded", () => {
    const hamburger = document.getElementById("hamburgerMenu");
    const megaMenu = document.getElementById("megaMenu");
    const header = document.querySelector("header");

    if (hamburger && megaMenu) {
        hamburger.addEventListener("click", () => {
            megaMenu.style.display = megaMenu.style.display === "block" ? "none" : "block";
        });

        document.addEventListener("click", (e) => {
            if (!e.target.closest("#megaMenu") && !e.target.closest("#hamburgerMenu")) {
                megaMenu.style.display = "none";
            }
        });
        
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                megaMenu.style.display = "none";
            }
        });
    }

    if (header) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 60) {
                header.classList.add("scrolled");
            } else {
                header.classList.remove("scrolled");
            }
        });
    }
});
