// Get context path dynamically
function getContextPath() {
    const pathArray = window.location.pathname.split('/');
    if (pathArray.length > 1 && pathArray[1] !== '') {
        return '/' + pathArray[1];
    }
    return '';
}

document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("mainSearchInput");
    const searchDropdown = document.getElementById("searchDropdown");
    const searchBtn = document.getElementById("searchSubmitBtn");
    
    let debounceTimer;

    if (searchInput) {
        searchInput.addEventListener("input", (e) => {
            clearTimeout(debounceTimer);
            const val = e.target.value;
            
            if (val.length >= 2) {
                debounceTimer = setTimeout(() => {
                    fetchSuggestions(val);
                }, 300);
            } else {
                searchDropdown.classList.remove("show");
            }
        });

        searchInput.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                const val = searchInput.value.trim();
                if (val) {
                    window.location.href = `${getContextPath()}/product?type=results&q=${encodeURIComponent(val)}`;
                }
            }
        });

        searchBtn.addEventListener("click", () => {
            const val = searchInput.value.trim();
            if (val) window.location.href = `${getContextPath()}/product?type=results&q=${encodeURIComponent(val)}`;
        });
    }

    document.addEventListener("click", (e) => {
        if (!e.target.closest(".search-card")) {
            if (searchDropdown) searchDropdown.classList.remove("show");
        }
    });

    function fetchSuggestions(query) {
        fetch(`${getContextPath()}/product?type=search&q=${encodeURIComponent(query)}`)
            .then(res => res.json())
            .then(data => {
                if (data.length > 0) {
                    searchDropdown.innerHTML = "";
                    data.forEach(item => {
                        const div = document.createElement("div");
                        div.className = "flex-row align-center";
                        div.style.padding = "8px 16px";
                        div.style.cursor = "pointer";
                        div.style.borderBottom = "1px solid #eee";
                        div.innerHTML = `
                            <img src="${item.image_url}" style="width:32px; height:32px; object-fit:cover; margin-right:12px; border-radius:4px;">
                            <div style="flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; font-size:13px;">${item.title}</div>
                            <div style="color:#FF6A00; font-weight:700; margin-left:12px;">$${item.price_min}</div>
                        `;
                        div.onclick = () => window.location.href = `${getContextPath()}/product?type=detail&id=${item.id}`;
                        searchDropdown.appendChild(div);
                    });
                    searchDropdown.classList.add("show");
                } else {
                    searchDropdown.classList.remove("show");
                }
            }).catch(err => console.error(err));
    }
});
