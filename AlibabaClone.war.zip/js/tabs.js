document.addEventListener("DOMContentLoaded", () => {
    // Top nav tabs (AI Mode, Products, etc.)
    const searchTabs = document.querySelectorAll(".search-tab");
    searchTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            searchTabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
        });
    });

    // Content Tabs (e.g. ProductDetail pages)
    const contentTabs = document.querySelectorAll(".tab-link");
    const contentPanes = document.querySelectorAll(".tab-pane");

    contentTabs.forEach(tab => {
        tab.addEventListener("click", (e) => {
            e.preventDefault();
            contentTabs.forEach(t => t.classList.remove("active"));
            contentPanes.forEach(p => p.style.display = "none");
            
            tab.classList.add("active");
            const target = document.getElementById(tab.dataset.target);
            if (target) target.style.display = "block";
        });
    });
});
