// Get context path dynamically
function getContextPath() {
    const pathArray = window.location.pathname.split('/');
    if (pathArray.length > 1 && pathArray[1] !== '') {
        return '/' + pathArray[1];
    }
    return '';
}

document.addEventListener("DOMContentLoaded", () => {
    const rfqForm = document.getElementById("rfqForm");

    if (rfqForm) {
        rfqForm.addEventListener("submit", (e) => {
            e.preventDefault();
            
            const formData = new URLSearchParams(new FormData(rfqForm));
            formData.append("action", "rfq");
            
            fetch(`${getContextPath()}/product`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: formData.toString()
            })
            .then(res => {
                if(res.status === 401) {
                    window.location.href = `${getContextPath()}/views/login.jsp`;
                    return null;
                }
                return res.json();
            })
            .then(data => {
                if (data && data.status === "success") {
                    if(typeof showToast === 'function') {
                        showToast("RFQ Submitted Successfully", "success");
                    } else {
                        alert("RFQ Submitted Successfully");
                    }
                    rfqForm.reset();
                }
            })
            .catch(err => console.error(err));
        });
    }
});
