// Get context path dynamically
function getContextPath() {
    const pathArray = window.location.pathname.split('/');
    if (pathArray.length > 1 && pathArray[1] !== '') {
        return '/' + pathArray[1];
    }
    return '';
}

const contextPath = getContextPath();

function addToCart(productId, qty) {
    console.log("Add to cart called for product:", productId, "quantity:", qty);
    const formData = new URLSearchParams();
    formData.append("action", "add");
    formData.append("productId", productId);
    formData.append("qty", qty);

    fetch(contextPath + '/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
    })
    .then(res => {
        console.log("Response status:", res.status);
        if (res.status === 401) {
            window.location.href = contextPath + '/views/login.jsp';
            return null;
        }
        if (res.status === 403) {
            // User tried to add their own product
            return res.json().then(data => {
                showToast("You cannot add your own products to cart!", "error");
                return null;
            });
        }
        return res.json();
    })
    .then(data => {
        if (data && data.status === "success") {
            showToast("Added to cart successfully!", "success");
        } else if (data && data.message) {
            showToast(data.message, "error");
        } else if (data === null) {
            // Already handled
            return;
        }
        console.log("Response data:", data);
    })
    .catch(err => console.error("Error adding to cart:", err));
}

function updateCartQty(productId, qtyStr, rowId) {
    const qty = parseInt(qtyStr);
    if(qty < 1) return;

    const formData = new URLSearchParams();
    formData.append("action", "update_qty");
    formData.append("productId", productId);
    formData.append("qty", qty);

    fetch(contextPath + '/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success") {
            // Update UI line totals
            const row = document.getElementById(rowId);
            const price = parseFloat(row.dataset.price);
            row.querySelector('.subtotal').innerText = '$' + (price * qty).toFixed(2);
            calculateGrandTotal();
        }
    });
}

function removeFromCart(productId, rowId) {
    const formData = new URLSearchParams();
    formData.append("action", "remove");
    formData.append("productId", productId);

    fetch(contextPath + '/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "success") {
            document.getElementById(rowId).remove();
            calculateGrandTotal();
        }
    });
}

function calculateGrandTotal() {
    let total = 0;
    document.querySelectorAll('.cart-row').forEach(row => {
        const price = parseFloat(row.dataset.price);
        const qty = parseInt(row.querySelector('.qty-input').value);
        total += (price * qty);
    });
    const summary = document.getElementById('cartSummaryTotal');
    if (summary) summary.innerText = '$' + total.toFixed(2);
}

function showToast(message, type) {
    const toast = document.createElement("div");
    toast.style.position = "fixed";
    toast.style.bottom = "20px";
    toast.style.right = "20px";
    toast.style.background = type === "success" ? "var(--badge-green)" : "#d9534f";
    toast.style.color = "#fff";
    toast.style.padding = "10px 20px";
    toast.style.borderRadius = "4px";
    toast.style.zIndex = "9999";
    toast.innerText = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}
