<%@ include file="/includes/header.jsp" %>
<div class="container section-padding" style="margin-top:20px;">
    <!-- Banner -->
    <div style="background:linear-gradient(270deg, #1e3c72 0%, #2a5298 100%); color:#fff; padding:40px 24px; border-radius:8px; margin-bottom:24px;">
        <h1 style="font-size:32px;">Category Products</h1>
        <p style="margin-top:8px;">Discover a wide range of offerings</p>
    </div>

    <!-- Sub categories link pills row -->
    <div class="scrollable-row" style="margin-bottom:24px;">
        <span class="pill-badge" style="background:#fff; padding:8px 16px; font-size:14px; border-radius:20px; cursor:pointer;">Smartphones</span>
        <span class="pill-badge" style="background:#fff; padding:8px 16px; font-size:14px; border-radius:20px; cursor:pointer;">Accessories</span>
        <span class="pill-badge" style="background:#fff; padding:8px 16px; font-size:14px; border-radius:20px; cursor:pointer;">Laptops</span>
        <span class="pill-badge" style="background:#fff; padding:8px 16px; font-size:14px; border-radius:20px; cursor:pointer;">Audio</span>
    </div>

    <div class="product-grid">
        <c:forEach var="p" items="${products}">
            <div class="product-card" onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                <div class="card-img-wrapper">
                    <img src="${p.imageUrl}" alt="${p.title}">
                </div>
                <div class="card-body">
                    <div class="card-title">${p.title}</div>
                    <div class="card-price">$${p.priceMin}</div>
                    <div class="card-moq">MOQ: ${p.minOrderQty} ${p.unit}</div>
                    <div class="card-supplier-info" style="margin-top:6px;">
                        <c:if test="${p.supplier.verified}"><span class="text-verified">Verified</span> · </c:if>
                        ${p.supplier.yearsOnPlatform} yrs · ${p.supplier.countryCode}
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>
</div>
<%@ include file="/includes/footer.jsp" %>
