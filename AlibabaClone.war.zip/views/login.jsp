<%@ include file="/includes/header.jsp" %>
<div style="min-height: 70vh; display:flex; align-items:center; justify-content:center; background: #f5f5f5;">
    <div style="width:100%; max-width:400px; background:#fff; padding:32px; border-radius:8px; box-shadow:var(--shadow-card);">
        <h2 style="text-align:center; margin-bottom:24px;">Sign In</h2>
        <c:if test="${param.error == 'true'}">
            <div style="color:red; background:#ffeeee; padding:10px; border-radius:4px; margin-bottom:16px; text-align:center; font-size:13px;">Invalid email or password.</div>
        </c:if>
        <c:if test="${param.success == 'true'}">
            <div style="color:green; background:#eeffee; padding:10px; border-radius:4px; margin-bottom:16px; text-align:center; font-size:13px;">Registration successful. Please login.</div>
        </c:if>
        <form action="${pageContext.request.contextPath}/user" method="POST">
            <input type="hidden" name="action" value="login">
            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:8px; font-size:13px; font-weight:600;">Email</label>
                <input type="email" name="email" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom:24px;">
                <label style="display:block; margin-bottom:8px; font-size:13px; font-weight:600;">Password</label>
                <input type="password" name="password" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                <div style="margin-top:8px; text-align:right;">
                    <a href="#" class="text-muted" style="font-size:12px;">Forgot password?</a>
                </div>
            </div>
            <button class="btn-primary" type="submit" style="width:100%; font-size:16px;">Sign In</button>
        </form>
        <div style="margin-top:24px; text-align:center; font-size:13px;">
            New to Alibaba? <a href="${pageContext.request.contextPath}/views/register.jsp" class="text-accent">Join Free</a>
        </div>
    </div>
</div>
<%@ include file="/includes/footer.jsp" %>
