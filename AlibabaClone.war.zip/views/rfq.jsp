<%@ include file="/includes/header.jsp" %>
<div class="container section-padding" style="margin-top:24px; max-width:800px; margin-left:auto; margin-right:auto; background:#fff; border-radius:8px; box-shadow:var(--shadow-card);">
    <h2 style="margin-bottom:24px; text-align:center;">Request for Quotation</h2>
    <form id="rfqForm">
        <div style="margin-bottom:16px;">
            <label style="display:block; margin-bottom:8px; font-weight:600;">Product Name *</label>
            <input type="text" name="product_name" required value="${param.q}" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
        </div>
        
        <div class="flex-row" style="gap:16px; margin-bottom:16px;">
            <div style="flex:1;">
                <label style="display:block; margin-bottom:8px; font-weight:600;">Quantity *</label>
                <input type="number" name="quantity" required min="1" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="flex:1;">
                <label style="display:block; margin-bottom:8px; font-weight:600;">Unit</label>
                <select name="unit" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                    <option value="pieces">Pieces</option>
                    <option value="sets">Sets</option>
                    <option value="kg">Kilograms</option>
                    <option value="pairs">Pairs</option>
                </select>
            </div>
        </div>

        <div style="margin-bottom:24px;">
            <label style="display:block; margin-bottom:8px; font-weight:600;">Detailed Requirements *</label>
            <textarea name="description" required rows="6" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;" placeholder="Please input product details, material, color, size, etc."></textarea>
        </div>

        <button type="submit" class="btn-primary" style="width:100%; font-size:16px; padding:12px;">Submit RFQ</button>
    </form>
</div>
<script src="${pageContext.request.contextPath}/js/rfq.js"></script>
<%@ include file="/includes/footer.jsp" %>
