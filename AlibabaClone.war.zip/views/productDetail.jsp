<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="/includes/header.jsp" %>
<div class="container section-padding" style="margin-top:20px; background:#fff;">
    <div class="flex-row" style="gap:40px;">
        <!-- Left: Image -->
        <div style="flex:4;">
            <img src="${fn:startsWith(product.imageUrl, 'http') ? '' : pageContext.request.contextPath}${product.imageUrl}" style="width:100%; aspect-ratio:1; object-fit:cover; border-radius:8px; border:1px solid #eee;" id="mainImage">
            <div class="flex-row" style="gap:10px; margin-top:10px; overflow-x:auto;">
                <img src="${fn:startsWith(product.imageUrl, 'http') ? '' : pageContext.request.contextPath}${product.imageUrl}" style="width:60px; height:60px; object-fit:cover; border:1px solid var(--accent); cursor:pointer; border-radius:4px;">
                <!-- Add more thumbnails ideally -->
            </div>
        </div>

        <!-- Right: Details -->
        <div style="flex:6;">
            <h1 style="font-size:20px; margin-bottom:12px;">${product.title}</h1>
            <div style="font-size:11px; color:#888; margin-bottom:8px;">CE · FCC · RoHS</div>
            
            <div style="margin-bottom:16px;">
                <span style="color:#FF9900;">★★★★☆</span> 
                <a href="#reviews" class="text-accent" style="font-size:13px; text-decoration:underline;">${product.reviewCount} Reviews</a>
                <span class="text-muted" style="font-size:13px;"> · ${product.soldCount} sold</span>
            </div>

            <div style="background:#f9f9f9; padding:16px; border-radius:8px; margin-bottom:20px;">
                <div style="font-size:28px; font-weight:700; color:#222;">
                    $${product.priceMin} <c:if test="${product.priceMin != product.priceMax}">– $${product.priceMax}</c:if>
                    <span style="font-size:13px; color:#888; font-weight:normal;">/ ${product.unit}</span>
                </div>
                <div style="margin-top:8px;">
                    <span class="badge-green-pill">MOQ: ${product.minOrderQty} ${product.unit}</span>
                </div>
            </div>

            <div style="border-top:1px solid #eee; border-bottom:1px solid #eee; padding:16px 0; margin-bottom:24px;">
                <a href="${pageContext.request.contextPath}/supplier?id=${product.supplier.id}" style="text-decoration:none;">
                    <div style="font-weight:700; color:#333; font-size:14px; margin-bottom:4px;">${product.supplier.companyName}</div>
                    <div class="text-verified" style="font-size:13px;">Verified</div>
                    <span class="text-muted" style="font-size:13px;"> · ${product.supplier.yearsOnPlatform} yrs · ${product.supplier.countryCode}</span>
                </a>
            </div>

            <div class="flex-row align-center" style="gap:16px; margin-bottom:24px;">
                <input type="number" id="qtyInput" value="${product.minOrderQty}" min="${product.minOrderQty}" style="width:80px; padding:10px; font-size:16px; text-align:center; border:1px solid #ccc; border-radius:4px;">
                <c:choose>
                    <c:when test="${empty sessionScope.loggedInUser}">
                        <!-- User not logged in -->
                        <button class="btn-primary" style="flex:1; padding:12px; font-size:16px;" onclick="window.location.href='${pageContext.request.contextPath}/views/login.jsp'">Sign In to Add to Cart</button>
                    </c:when>
                    <c:when test="${sessionScope.loggedInUser.id == product.supplier.userId}">
                        <!-- Own product - cannot add -->
                        <button class="btn-primary" style="flex:1; padding:12px; font-size:16px; background:#ccc; cursor:not-allowed;" disabled>You Cannot Add Your Own Product</button>
                    </c:when>
                    <c:otherwise>
                        <!-- Other's product - can add -->
                        <button class="btn-primary" style="flex:1; padding:12px; font-size:16px;" onclick="addToCart(${product.id}, document.getElementById('qtyInput').value)">Add to Cart</button>
                    </c:otherwise>
                </c:choose>
                <button class="btn-primary" style="flex:1; padding:12px; font-size:16px; background:#fff; color:var(--accent); border:1px solid var(--accent);">Contact Supplier</button>
            </div>
            
            <a href="${pageContext.request.contextPath}/views/rfq.jsp?q=${product.title}" class="text-accent" style="font-size:14px; text-decoration:underline;">Request for Quotation</a>
        </div>
    </div>

    <!-- Tabs section -->
    <div style="margin-top:40px;">
        <div style="border-bottom:1px solid #eee; display:flex; gap:32px;">
            <div class="search-tab tab-link active" data-target="desc">Product Description</div>
            <div class="search-tab tab-link" data-target="capa">Supplier Capabilities</div>
            <div class="search-tab tab-link" data-target="revi" id="reviews">Customer Reviews</div>
        </div>
        <div style="padding:24px 0;">
            <div id="desc" class="tab-pane" style="display:block;">
                <h3>Product Details</h3>
                <p style="margin-top:12px; color:#555; line-height:1.6;">${product.description}</p>
            </div>
            <div id="capa" class="tab-pane" style="display:none;">
                <h3>Supplier Attributes</h3>
                <ul style="margin-top:12px; color:#555; padding-left:20px; line-height:1.6;">
                    <li>Response Rate: ${product.supplier.responseRate}%</li>
                    <li>On-time Delivery Rate: 98.5%</li>
                    <li>OEM/ODM services available</li>
                </ul>
            </div>
            <div id="revi" class="tab-pane" style="display:none;">
                <h3>Reviews</h3>
                <p style="margin-top:12px; color:#555;">Review form for logged-in users and list of reviews go here.</p>
            </div>
        </div>
    </div>
</div>
<%@ include file="/includes/footer.jsp" %>
