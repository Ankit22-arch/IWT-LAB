<%@ include file="/includes/header.jsp" %>
<div style="min-height: 80vh; display:flex; align-items:center; justify-content:center; background: #f5f5f5; padding: 40px 0;">
    <div style="width:100%; max-width:500px; background:#fff; padding:32px; border-radius:8px; box-shadow:var(--shadow-card);">
        <h2 style="text-align:center; margin-bottom:24px;">Create Account</h2>
        <c:choose>
            <c:when test="${param.error == 'exists'}">
                <div style="color:red; background:#ffeeee; padding:10px; border-radius:4px; margin-bottom:16px; text-align:center; font-size:13px;">An account with these details already exists.</div>
            </c:when>
            <c:when test="${param.error == 'true'}">
                <div style="color:red; background:#ffeeee; padding:10px; border-radius:4px; margin-bottom:16px; text-align:center; font-size:13px;">Registration failed. Please try again.</div>
            </c:when>
        </c:choose>
        <form action="${pageContext.request.contextPath}/user" method="POST" id="registerForm">
            <input type="hidden" name="action" value="register">
            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:8px; font-size:13px; font-weight:600;">Full Name</label>
                <input type="text" name="username" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:8px; font-size:13px; font-weight:600;">Email</label>
                <input type="email" name="email" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom:16px;">
                <label style="display:block; margin-bottom:8px; font-size:13px; font-weight:600;">Password</label>
                <input type="password" name="password" id="regPass" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom:24px;">
                <label style="display:block; margin-bottom:8px; font-size:13px; font-weight:600;">Confirm Password</label>
                <input type="password" id="regPassConfirm" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                <div id="passError" style="color:red; font-size:12px; display:none; margin-top:4px;"></div>
            </div>
            
            <div style="margin-bottom:24px;">
                <label style="display:block; margin-bottom:8px; font-size:13px; font-weight:600;">Role</label>
                <div style="display:flex; gap:16px;">
                    <label><input type="radio" name="role" value="buyer" checked> Buyer</label>
                    <label><input type="radio" name="role" value="supplier"> Supplier</label>
                </div>
            </div>

            <button class="btn-primary" type="submit" style="width:100%; font-size:16px;" onclick="return validateReg()">Create Account</button>
        </form>
        <div style="margin-top:24px; text-align:center; font-size:13px;">
            Already have an account? <a href="${pageContext.request.contextPath}/views/login.jsp" class="text-accent">Sign In</a>
        </div>
    </div>
</div>
<script>
    function validateReg() {
        const p1 = document.getElementById("regPass").value;
        const p2 = document.getElementById("regPassConfirm").value;
        const errorEl = document.getElementById("passError");
        const allowedSpecials = /[@_&~$]/;

        if (p1.length < 8) {
            errorEl.textContent = "Password must be at least 8 characters.";
            errorEl.style.display = "block";
            return false;
        }
        if (!/[A-Z]/.test(p1) || !/[a-z]/.test(p1) || !/[0-9]/.test(p1) || !allowedSpecials.test(p1)) {
            errorEl.textContent = "Password must include A-Z, a-z, 0-9, and one of @ _ & ~ $.";
            errorEl.style.display = "block";
            return false;
        }
        if (p1 !== p2) {
            errorEl.textContent = "Passwords do not match.";
            errorEl.style.display = "block";
            return false;
        }

        errorEl.style.display = "none";
        return true;
    }
</script>
<%@ include file="/includes/footer.jsp" %>
