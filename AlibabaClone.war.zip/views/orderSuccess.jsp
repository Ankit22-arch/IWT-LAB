<%@ include file="/includes/header.jsp" %>

<div class="container section-padding" style="margin-top:20px; max-width:900px;">
    <c:choose>
        <c:when test="${empty order}">
            <div style="background:#fff; padding:32px; border-radius:10px; box-shadow:var(--shadow-card); text-align:center;">
                <h2>Order status unavailable</h2>
                <p style="color:#666; margin-top:8px;">Please return to your cart and try again.</p>
                <a href="${pageContext.request.contextPath}/cart" class="btn-primary" style="display:inline-block; margin-top:16px; padding:10px 24px;">Back to Cart</a>
            </div>
        </c:when>
        <c:otherwise>
            <div style="background:#fff; padding:32px; border-radius:10px; box-shadow:var(--shadow-card);">
                <div id="addressStep">
                    <div style="text-align:center;">
                        <h2>Select delivery address</h2>
                        <p style="color:#666; margin-top:8px;">Choose an address or add a new one to place your order.</p>
                    </div>
                    <div id="addressList" style="margin-top:16px; display:grid; gap:12px;"></div>
                    <div style="margin-top:20px; border-top:1px dashed #eee; padding-top:16px;">
                        <div style="font-weight:600;">Add new address</div>
                        <div style="color:#777; margin-top:4px;">Saved locally in this browser (not in the database).</div>
                        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:12px; margin-top:12px;">
                            <input type="text" id="newAddressName" placeholder="Full name *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                            <input type="text" id="newAddressLine1" placeholder="Address line 1 *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                            <input type="text" id="newAddressLine2" placeholder="Address line 2" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                            <input type="text" id="newAddressCity" placeholder="City *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                            <input type="text" id="newAddressState" placeholder="State/Province *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                            <input type="text" id="newAddressZip" placeholder="Postal code *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                            <input type="text" id="newAddressCountry" placeholder="Country *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                            <input type="text" id="newAddressPhone" placeholder="Phone" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        </div>
                        <div style="margin-top:12px; display:flex; gap:12px; flex-wrap:wrap;">
                            <button type="button" id="addAddressBtn" class="btn-accent-outline" style="padding:10px 20px;">Add Address</button>
                        </div>
                        <div id="newAddressError" style="display:none; color:#c00; margin-top:8px;">Please fill in the required fields to add a new address.</div>
                    </div>
                    <div style="margin-top:20px; display:flex; gap:12px; flex-wrap:wrap;">
                        <button type="button" id="confirmAddressBtn" class="btn-primary" style="padding:10px 20px;">Confirm Address & Place Order</button>
                        <a href="${pageContext.request.contextPath}/cart" class="btn-accent-outline" style="padding:10px 20px;">Back to Cart</a>
                    </div>
                    <div id="addressError" style="display:none; color:#c00; margin-top:8px;">Please select an address to continue.</div>
                </div>
                <div id="successStep" style="display:none;">
                    <div style="text-align:center;">
                        <div style="font-size:48px; color:#28a745; margin-bottom:8px;"><i class="fa-regular fa-circle-check"></i></div>
                        <h2>Your order has been placed successfully</h2>
                        <p style="color:#666; margin-top:8px;">Thank you for shopping with us.</p>
                    </div>
                    <div style="margin-top:24px; border-top:1px solid #eee; padding-top:20px;">
                        <div class="flex-row flex-space-between" style="margin-bottom:8px;">
                            <span style="color:#777;">Order Number</span>
                            <span style="font-weight:600;">${order.orderNumber}</span>
                        </div>
                        <div class="flex-row flex-space-between" style="margin-bottom:8px;">
                            <span style="color:#777;">Placed On</span>
                            <span>${order.placedAt}</span>
                        </div>
                        <div class="flex-row flex-space-between" style="margin-bottom:8px;">
                            <span style="color:#777;">Deliver To</span>
                            <span id="selectedAddressSummary" style="font-weight:600;"></span>
                        </div>
                        <div class="flex-row flex-space-between" style="margin-bottom:8px;">
                            <span style="color:#777;">Total</span>
                            <span style="font-weight:700; color:#FF6A00;">$${order.total}</span>
                        </div>
                    </div>
                    <div style="margin-top:16px;">
                        <div style="font-weight:600; margin-bottom:8px;">Items</div>
                        <c:forEach var="item" items="${order.items}">
                            <div class="flex-row flex-space-between" style="padding:8px 0; border-bottom:1px solid #f0f0f0;">
                                <span>${item.product.title} × ${item.quantity}</span>
                                <span>$${item.product.priceMin * item.quantity}</span>
                            </div>
                        </c:forEach>
                    </div>
                    <div style="margin-top:24px; display:flex; gap:12px; flex-wrap:wrap;">
                        <a href="${pageContext.request.contextPath}/views/account.jsp#orders" class="btn-primary" style="padding:10px 20px;">View Order History</a>
                        <a href="${pageContext.request.contextPath}/" class="btn-accent-outline" style="padding:10px 20px;">Continue Shopping</a>
                    </div>
                </div>
            </div>
        </c:otherwise>
    </c:choose>
</div>

<script>
    (function() {
        var storageKey = "ag_address_book";
        var hiddenKey = "ag_address_hidden";
        var addressStep = document.getElementById("addressStep");
        var successStep = document.getElementById("successStep");
        var addressList = document.getElementById("addressList");
        var confirmBtn = document.getElementById("confirmAddressBtn");
        var addBtn = document.getElementById("addAddressBtn");
        var addressError = document.getElementById("addressError");
        var newAddressError = document.getElementById("newAddressError");
        var summary = document.getElementById("selectedAddressSummary");

        var defaultAddresses = [
            {
                id: "addr-default-1",
                name: "Aisha Khan",
                line1: "23 Lake View Road",
                line2: "",
                city: "Colombo 03",
                state: "Western",
                zip: "00300",
                country: "Sri Lanka",
                phone: "+94 77 123 4567"
            },
            {
                id: "addr-default-2",
                name: "Naveen Perera",
                line1: "88 Market Street",
                line2: "",
                city: "Kandy",
                state: "Central",
                zip: "20000",
                country: "Sri Lanka",
                phone: "+94 71 555 2211"
            },
            {
                id: "addr-default-3",
                name: "Imani Silva",
                line1: "12 Palm Grove",
                line2: "",
                city: "Galle",
                state: "Southern",
                zip: "80000",
                country: "Sri Lanka",
                phone: "+94 76 222 3311"
            }
        ];

        function getSelectedAddress() {
            return document.querySelector('input[name="addressOption"]:checked');
        }

        function loadSavedAddresses() {
            try {
                var raw = localStorage.getItem(storageKey);
                var parsed = raw ? JSON.parse(raw) : [];
                return Array.isArray(parsed) ? parsed : [];
            } catch (err) {
                return [];
            }
        }

        function loadHiddenDefaults() {
            try {
                var raw = localStorage.getItem(hiddenKey);
                var parsed = raw ? JSON.parse(raw) : [];
                return Array.isArray(parsed) ? parsed : [];
            } catch (err) {
                return [];
            }
        }

        function saveAddresses(addresses) {
            try {
                localStorage.setItem(storageKey, JSON.stringify(addresses));
            } catch (err) {
                return;
            }
        }

        function showError(element, message) {
            if (!element) {
                return;
            }
            element.textContent = message;
            element.style.display = "block";
        }

        function hideError(element) {
            if (!element) {
                return;
            }
            element.style.display = "none";
        }

        function escapeHtml(text) {
            var map = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };
            return String(text).replace(/[&<>"']/g, function(match) {
                return map[match];
            });
        }

        function buildDisplay(address) {
            var line = address.name + ", " + address.line1;
            if (address.line2) {
                line += ", " + address.line2;
            }
            line += ", " + address.city + ", " + address.state + " " + address.zip + ", " + address.country;
            return line;
        }

        function createAddressOption(address, selectedId) {
            var label = document.createElement("label");
            label.style.cssText = "display:flex; gap:12px; align-items:flex-start; padding:12px; border:1px solid #eee; border-radius:8px; cursor:pointer;";

            var input = document.createElement("input");
            input.type = "radio";
            input.name = "addressOption";
            input.value = address.id;
            input.setAttribute("data-display", buildDisplay(address));
            input.style.marginTop = "4px";
            if (selectedId && address.id === selectedId) {
                input.checked = true;
            }

            var info = document.createElement("div");
            info.innerHTML = "<div style=\"font-weight:600;\">" + escapeHtml(address.name) + "</div>"
                + "<div style=\"color:#555;\">" + escapeHtml(address.line1) + "</div>"
                + (address.line2 ? "<div style=\"color:#555;\">" + escapeHtml(address.line2) + "</div>" : "")
                + "<div style=\"color:#555;\">" + escapeHtml(address.city) + ", " + escapeHtml(address.state) + " " + escapeHtml(address.zip) + "</div>"
                + "<div style=\"color:#555;\">" + escapeHtml(address.country) + "</div>"
                + (address.phone ? "<div style=\"color:#777;\">" + escapeHtml(address.phone) + "</div>" : "");

            label.appendChild(input);
            label.appendChild(info);
            return label;
        }

        function renderAddressList(selectedId) {
            if (!addressList) {
                return;
            }
            addressList.innerHTML = "";
            var hidden = loadHiddenDefaults();
            var combined = defaultAddresses.filter(function(address) {
                return hidden.indexOf(address.id) === -1;
            }).concat(loadSavedAddresses());
            combined.forEach(function(address) {
                addressList.appendChild(createAddressOption(address, selectedId));
            });
        }

        confirmBtn.addEventListener("click", function() {
            var selected = getSelectedAddress();
            if (!selected) {
                showError(addressError, "Please select an address to continue.");
                return;
            }
            hideError(addressError);
            hideError(newAddressError);
            summary.textContent = selected.getAttribute("data-display") || "";
            addressStep.style.display = "none";
            successStep.style.display = "block";
        });

        addBtn.addEventListener("click", function() {
            var name = document.getElementById("newAddressName").value.trim();
            var line1 = document.getElementById("newAddressLine1").value.trim();
            var line2 = document.getElementById("newAddressLine2").value.trim();
            var city = document.getElementById("newAddressCity").value.trim();
            var state = document.getElementById("newAddressState").value.trim();
            var zip = document.getElementById("newAddressZip").value.trim();
            var country = document.getElementById("newAddressCountry").value.trim();
            var phone = document.getElementById("newAddressPhone").value.trim();

            if (!name || !line1 || !city || !state || !zip || !country) {
                showError(newAddressError, "Please fill in the required fields to add a new address.");
                return;
            }

            hideError(newAddressError);
            hideError(addressError);
            var saved = loadSavedAddresses();
            var newAddress = {
                id: "addr-saved-" + Date.now(),
                name: name,
                line1: line1,
                line2: line2,
                city: city,
                state: state,
                zip: zip,
                country: country,
                phone: phone
            };
            saved.push(newAddress);
            saveAddresses(saved);
            renderAddressList(newAddress.id);

            document.getElementById("newAddressName").value = "";
            document.getElementById("newAddressLine1").value = "";
            document.getElementById("newAddressLine2").value = "";
            document.getElementById("newAddressCity").value = "";
            document.getElementById("newAddressState").value = "";
            document.getElementById("newAddressZip").value = "";
            document.getElementById("newAddressCountry").value = "";
            document.getElementById("newAddressPhone").value = "";
        });

        renderAddressList();
    })();
</script>

<%@ include file="/includes/footer.jsp" %>
