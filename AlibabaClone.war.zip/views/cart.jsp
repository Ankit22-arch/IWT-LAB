<%@ include file="/includes/header.jsp" %>
<div class="container section-padding" style="margin-top:20px;">
    <h2>Cart</h2>
    <div class="flex-row" style="gap:24px; margin-top:20px;">
        <div style="flex:2;">
            <table style="width:100%; border-collapse: collapse; text-align:left;">
                <tr style="border-bottom:1px solid #ddd; height:40px;">
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <th>Action</th>
                </tr>
                <c:forEach var="item" items="${cartItems}">
                    <tr class="cart-row" id="row-${item.productId}" data-price="${item.product.priceMin}" style="border-bottom:1px solid #eee;">
                        <td style="padding:16px 0;">
                            <div class="flex-row align-center">
                                <img src="${fn:startsWith(item.product.imageUrl, 'http') ? '' : pageContext.request.contextPath}${item.product.imageUrl}" style="width:80px; height:80px; object-fit:cover; border-radius:4px; margin-right:16px;">
                                <span>${item.product.title}</span>
                            </div>
                        </td>
                        <td>$${item.product.priceMin}</td>
                        <td>
                            <input type="number" value="${item.quantity}" min="1" class="qty-input" style="width:60px; padding:4px;" onchange="updateCartQty(${item.productId}, this.value, 'row-${item.productId}')">
                        </td>
                        <td class="subtotal" style="font-weight:bold;">$${item.product.priceMin * item.quantity}</td>
                        <td>
                            <button onclick="removeFromCart(${item.productId}, 'row-${item.productId}')" style="background:none; border:none; color:red;">Remove</button>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty cartItems}">
                    <tr><td colspan="5" style="padding:20px; text-align:center;">Your cart is empty.</td></tr>
                </c:if>
            </table>
        </div>
        <div style="flex:1;">
            <div style="background:#fff; padding:24px; border-radius:8px; box-shadow:var(--shadow-card);">
                <h3>Order Summary</h3>
                <div class="flex-row flex-space-between" style="margin-top:16px; font-size:18px; font-weight:bold;">
                    <span>Total:</span>
                    <span id="cartSummaryTotal">$0.00</span>
                </div>
                <c:choose>
                    <c:when test="${empty cartItems}">
                        <button class="btn-primary" style="width:100%; margin-top:24px;" disabled>Proceed to Checkout</button>
                    </c:when>
                    <c:otherwise>
                        <form method="post" action="${pageContext.request.contextPath}/checkout" style="margin-top:24px;">
                            <button class="btn-primary" style="width:100%;" type="submit">Proceed to Checkout</button>
                        </form>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </div>
</div>
<script src="${pageContext.request.contextPath}/js/cart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", calculateGrandTotal);
</script>
<%@ include file="/includes/footer.jsp" %>
