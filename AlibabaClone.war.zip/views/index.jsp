<%@ include file="/includes/header.jsp" %>

<!-- =============================================
     PAGE WRAPPER
     ============================================= -->
<div class="page-wrapper">

    <!-- ========================
         SECTION 1: Hero / Welcome
         ======================== -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-inner">
                <div class="hero-left">
                    <h1>Welcome to <span class="brand-highlight">Alibaba.com</span></h1>
                    <p>The world&rsquo;s largest B2B marketplace</p>
                </div>
                <div class="hero-shortcuts">
                    <a href="${pageContext.request.contextPath}/views/rfq.jsp" class="shortcut-chip">
                        <i class="fa-solid fa-file-invoice"></i> Request for Quotation
                    </a>
                    <a href="#top-ranking" class="shortcut-chip">
                        <i class="fa-solid fa-trophy"></i> Top Ranking
                    </a>
                    <a href="#fast-custom" class="shortcut-chip">
                        <i class="fa-solid fa-sliders"></i> Fast Customization
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- ========================
         SECTION 2: Sidebar + Promo
         ======================== -->
    <section class="section-block">
        <div class="container">
            <div class="home-layout">

                <!-- Categories Sidebar -->
                <aside class="categories-sidebar">
                    <h3><i class="fa-solid fa-layer-group"></i> Categories</h3>
                    <div class="cat-list-wrapper">
                        <button class="cat-scroll-btn" id="catScrollUp">
                            <i class="fa-solid fa-chevron-up"></i>
                        </button>
                        <ul class="cat-list" id="catList">
                            <c:forEach var="cat" items="${categories}">
                                <li class="cat-item"
                                    onclick="window.location.href='${pageContext.request.contextPath}/product?type=category&id=${cat.id}'">
                                    <i class="fa-solid fa-angle-right cat-arrow"></i>
                                    ${cat.name}
                                </li>
                            </c:forEach>
                        </ul>
                        <button class="cat-scroll-btn" id="catScrollDown">
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>
                    </div>
                </aside>

                <!-- Promo Grid -->
                <div class="promo-grid">
                    <div class="promo-stack">
                        <c:forEach var="rp" items="${recommended}" end="0">
                            <div class="promo-img-card"
                                 onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${rp.id}'">
                                <img src="${fn:startsWith(rp.imageUrl, 'http') ? '' : pageContext.request.contextPath}${rp.imageUrl}"
                                     alt="Recommended Product">
                                <div class="promo-img-label">Featured Pick</div>
                            </div>
                        </c:forEach>
                        <!-- Fallback second img slot -->
                        <div class="promo-img-card promo-img-accent">
                            <div class="promo-accent-content">
                                <i class="fa-solid fa-award"></i>
                                <div>Top Supplier</div>
                            </div>
                        </div>
                    </div>

                    <div class="promo-banner">
                        <div class="promo-banner-tag">
                            <i class="fa-solid fa-star"></i> MarchExpo
                        </div>
                        <div class="promo-banner-body">
                            <h2>March Expo<br>Leaderboard<br>Hot Picks</h2>
                            <div class="promo-trophy"><i class="fa-solid fa-trophy"></i></div>
                        </div>
                        <div class="promo-banner-footer">
                            <button class="btn-pill-dark">
                                <i class="fa-solid fa-bolt"></i> Source now
                            </button>
                            <div class="carousel-dots" style="margin-top:14px;">
                                <span class="dot active"></span>
                                <span class="dot"></span><span class="dot"></span>
                                <span class="dot"></span><span class="dot"></span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="recommended-label">
                <i class="fa-solid fa-wand-magic-sparkles"></i> Recommended for your business
            </div>
        </div>
    </section>

    <!-- ========================
         SECTION 3: Fast Customization
         ======================== -->
    <section class="section-block" id="fast-custom">
        <div class="container">
            <div class="section-split">
                <div class="section-split-info">
                    <h2>Fast Customization</h2>
                    <p>Realize your custom product ideas fast and easy</p>
                    <ul class="info-list">
                        <li><i class="fa-solid fa-check-circle"></i> Low MOQ</li>
                        <li><i class="fa-solid fa-check-circle"></i> 14-day dispatch</li>
                        <li><i class="fa-solid fa-check-circle"></i> Free design support</li>
                    </ul>
                    <a href="#" class="btn-accent-outline">
                        Explore now <i class="fa-solid fa-arrow-right"></i>
                    </a>
                </div>
                <div class="scrollable-row section-split-scroll">
                    <c:forEach var="p" items="${fastCustom}">
                        <div class="product-card scroll-card"
                             onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                            <div class="card-img-wrapper">
                                <img src="${fn:startsWith(p.imageUrl, 'http') ? '' : pageContext.request.contextPath}${p.imageUrl}"
                                     alt="${p.title}">
                                <div class="badge-customization">
                                    <i class="fa-solid fa-pen-nib"></i> Custom
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="card-title">${p.title}</div>
                                <div class="card-price">$${p.priceMin}</div>
                                <div class="card-moq">
                                    <i class="fa-solid fa-cubes"></i> MOQ: ${p.minOrderQty} ${p.unit}
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </div>
        </div>
    </section>

    <!-- ========================
         SECTION 4: Top Deals
         ======================== -->
    <section class="section-block">
        <div class="container">
            <div class="section-header">
                <div>
                    <h2><i class="fa-solid fa-fire-flame-curved" style="color:#FF5A00;"></i> Top Deals</h2>
                    <div class="sub-text">Score the lowest prices on Alibaba.com</div>
                </div>
                <a href="#" class="view-more-link">View more <i class="fa-solid fa-chevron-right"></i></a>
            </div>
            <div class="scrollable-row">
                <c:forEach var="p" items="${topDeals}">
                    <div class="product-card scroll-card"
                         onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                        <div class="card-img-wrapper">
                            <img src="${fn:startsWith(p.imageUrl, 'http') ? '' : pageContext.request.contextPath}${p.imageUrl}"
                                 alt="${p.title}">
                            <div class="badge-overlay-tl badge-discount">
                                <i class="fa-solid fa-tag"></i> ${p.discountPercent}% off
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card-title">${p.title}</div>
                            <div>
                                <span class="card-price">$${p.priceMin}</span>
                                <span class="card-old-price">$${p.originalPrice}</span>
                            </div>
                            <div class="card-moq">MOQ: ${p.minOrderQty}</div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>
    </section>

    <!-- ========================
         SECTION 5 & 6: Top Ranking + New Arrivals (side by side)
         ======================== -->
    <section class="section-block" id="top-ranking">
        <div class="container">
            <div class="dual-section-grid">

                <!-- Top Ranking -->
                <div class="dual-section-panel">
                    <div class="section-header">
                        <div>
                            <h2><i class="fa-solid fa-medal" style="color:#f59e0b;"></i> Top Ranking</h2>
                            <div class="sub-text">Navigate trends with data-driven rankings</div>
                        </div>
                        <a href="#" class="view-more-link">View more <i class="fa-solid fa-chevron-right"></i></a>
                    </div>
                    <div class="scrollable-row">
                        <c:forEach var="p" items="${topRanking}">
                            <div class="product-card scroll-card"
                                 onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                                <div class="card-img-wrapper">
                                    <img src="${fn:startsWith(p.imageUrl, 'http') ? '' : pageContext.request.contextPath}${p.imageUrl}"
                                         alt="${p.title}">
                                    <div class="badge-overlay-tl badge-green-pill">
                                        <i class="fa-solid fa-bolt"></i> 5-day
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="card-price">$${p.priceMin}</div>
                                    <div class="card-moq">MOQ: ${p.minOrderQty}</div>
                                </div>
                            </div>
                        </c:forEach>
                    </div>
                </div>

                <!-- Divider -->
                <div class="dual-section-divider"></div>

                <!-- New Arrivals -->
                <div class="dual-section-panel">
                    <div class="section-header">
                        <div>
                            <h2><i class="fa-solid fa-bag-shopping" style="color:#8b5cf6;"></i> New Arrivals</h2>
                            <div class="sub-text">Stay ahead with the latest offerings</div>
                        </div>
                        <a href="#" class="view-more-link">View more <i class="fa-solid fa-chevron-right"></i></a>
                    </div>
                    <div class="scrollable-row">
                        <c:forEach var="p" items="${newArrivals}">
                            <div class="product-card scroll-card"
                                 onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                                <div class="card-img-wrapper">
                                    <img src="${fn:startsWith(p.imageUrl, 'http') ? '' : pageContext.request.contextPath}${p.imageUrl}"
                                         alt="${p.title}">
                                    <div class="badge-overlay-tl badge-new">New</div>
                                </div>
                                <div class="card-body">
                                    <div class="card-price">$${p.priceMin}</div>
                                    <div class="card-moq">MOQ: ${p.minOrderQty}</div>
                                </div>
                            </div>
                        </c:forEach>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- ========================
         SECTION 7: Tailored Selections
         ======================== -->
    <section class="section-block">
        <div class="container">
            <div class="section-header">
                <div>
                    <h2><i class="fa-solid fa-wand-magic-sparkles" style="color:#8b5cf6;"></i> Tailored Selections</h2>
                    <div class="sub-text">Handpicked especially for your business</div>
                </div>
                <a href="#" class="view-more-link">View more <i class="fa-solid fa-chevron-right"></i></a>
            </div>
            <div class="product-grid">
                <c:forEach var="p" items="${tailored}">
                    <div class="product-card"
                         onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                        <div class="card-img-wrapper">
                            <img src="${fn:startsWith(p.imageUrl, 'http') ? '' : pageContext.request.contextPath}${p.imageUrl}"
                                 alt="${p.title}">
                        </div>
                        <div class="card-body">
                            <div class="card-price-range">
                                $${p.priceMin} &ndash; $${p.priceMax}
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>
    </section>

</div><!-- end .page-wrapper -->

<%@ include file="/includes/footer.jsp" %>
