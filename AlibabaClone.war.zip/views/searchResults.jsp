<%@ include file="/includes/header.jsp" %>
<div class="container" style="padding:20px 24px;">
    
    <div class="flex-row flex-space-between align-center" style="margin-bottom:16px;">
        <div class="text-muted" style="font-size:13px;">${products.size()} results for '<span style="color:#222; font-weight:600;">${keyword}</span>'</div>
        <div>
            <span style="font-size:13px; color:#555; margin-right:8px;">Sort by:</span>
            <select onchange="window.location.href='${pageContext.request.contextPath}/product?type=results&q=${keyword}&sortBy='+this.value">
                <option value="best_match" ${param.sortBy == 'best_match' ? 'selected' : ''}>Best Match</option>
                <option value="price_asc" ${param.sortBy == 'price_asc' ? 'selected' : ''}>Price: Low to High</option>
                <option value="price_desc" ${param.sortBy == 'price_desc' ? 'selected' : ''}>Price: High to Low</option>
                <option value="newest" ${param.sortBy == 'newest' ? 'selected' : ''}>Newest</option>
            </select>
        </div>
    </div>
    
    <div class="flex-row" style="gap:8px; margin-bottom:24px; flex-wrap:wrap;">
        <span class="pill-badge" style="background:#fff;">Trade Assurance ✕</span>
        <span class="pill-badge" style="background:#fff;">Verified Supplier ✕</span>
        <span class="pill-badge" style="background:#fff;">Ready to Ship ✕</span>
    </div>

    <div class="product-grid">
        <c:forEach var="p" items="${products}">
            <div class="product-card" onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                <div class="card-img-wrapper">
                    <img src="${p.imageUrl}" alt="${p.title}">
                    <div class="visual-search-btn">📷</div>
                    <c:if test="${p.discountPercent > 0}">
                        <div class="badge-overlay-tl badge-discount">${p.discountPercent}% off</div>
                    </c:if>
                </div>
                <div class="card-body">
                    <div class="card-title">${p.title}</div>
                    
                    <c:if test="${p.listedDaysAgo <= 60}">
                        <div style="color:var(--accent); font-size:11px; margin-bottom:2px;">Listed in last 60 days</div>
                    </c:if>
                    
                    <div>
                        <span class="card-price">$${p.priceMin}</span>
                    </div>
                    
                    <c:if test="${not empty p.badgeText}">
                        <div class="price-badge">${p.badgeText}</div>
                    </c:if>
                    
                    <c:if test="${p.dispatchDays <= 5}">
                        <div class="dispatch-dot">5-day dispatch</div>
                    </c:if>

                    <div class="card-moq">MOQ: ${p.minOrderQty} ${p.unit}</div>
                    
                    <div class="card-supplier-info" style="margin-top:6px;">
                        <c:if test="${p.soldCount > 0}">${p.soldCount} sold · </c:if>
                        <c:if test="${p.supplier.verified}"><span class="text-verified">Verified</span> · </c:if>
                        ${p.supplier.yearsOnPlatform} yrs · ${p.supplier.countryCode}
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>
    
    <div style="text-align:center; padding:40px 0;">
        <button class="btn-primary" style="background:#fff; color:#333; border:1px solid #ccc;">Load more</button>
    </div>
</div>
<%@ include file="/includes/footer.jsp" %>
