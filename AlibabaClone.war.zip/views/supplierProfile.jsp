<%@ include file="/includes/header.jsp" %>
<div class="container section-padding" style="margin-top:20px; background:#fff;">
    <div style="background:linear-gradient(to right, #eef2f3, #8e9eab); height:160px; border-radius:8px; position:relative;">
        <!-- Banner overlay logo -->
        <div style="position:absolute; bottom:-40px; left:40px; width:100px; height:100px; background:#fff; border-radius:8px; padding:10px; box-shadow:var(--shadow-card);">
            <div style="width:100%; height:100%; background:#f0f0f0; display:flex; align-items:center; justify-content:center; text-align:center; font-size:12px; color:#888;">Supplier<br>Logo</div>
        </div>
    </div>
    
    <div style="margin-bottom:40px; padding-left:160px; padding-top:16px;">
        <h1 style="font-size:24px; margin-bottom:8px;">${supplier.companyName}</h1>
        <div class="flex-row align-center" style="gap:16px;">
            <span class="text-verified" style="font-size:14px;">Verified</span>
            <span class="text-muted" style="font-size:14px;">${supplier.yearsOnPlatform} yrs · ${supplier.country}</span>
            <c:if test="${supplier.tradeAssurance}">
                <span style="color:#FF9900; border:1px solid #FF9900; padding:2px 6px; border-radius:4px; font-size:11px;">Trade Assurance</span>
            </c:if>
        </div>
        <div class="flex-row" style="gap:32px; margin-top:16px;">
            <div><div style="font-size:18px; font-weight:700;">${supplier.responseRate}%</div><div class="text-muted" style="font-size:12px;">Response Rate</div></div>
            <div><div style="font-size:18px; font-weight:700;">98.5%</div><div class="text-muted" style="font-size:12px;">On-time Delivery</div></div>
            <div><div style="font-size:18px; font-weight:700;">$1M+</div><div class="text-muted" style="font-size:12px;">Annual Revenue</div></div>
        </div>
    </div>

    <!-- Tabs section -->
    <div>
        <div style="border-bottom:1px solid #eee; display:flex; gap:32px;">
            <div class="search-tab tab-link active" data-target="prods">Products</div>
            <div class="search-tab tab-link" data-target="prof">Company Profile</div>
            <div class="search-tab tab-link" data-target="certs">Certifications</div>
        </div>
        <div style="padding:24px 0;">
            <div id="prods" class="tab-pane" style="display:block;">
                <div class="product-grid">
                    <c:forEach var="p" items="${products}">
                        <div class="product-card" onclick="window.location.href='${pageContext.request.contextPath}/product?type=detail&id=${p.id}'">
                            <div class="card-img-wrapper"><img src="${p.imageUrl}"></div>
                            <div class="card-body">
                                <div class="card-title">${p.title}</div>
                                <div class="card-price">$${p.priceMin}</div>
                                <div class="card-moq">MOQ: ${p.minOrderQty}</div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </div>
            <div id="prof" class="tab-pane" style="display:none;">
                <p>${supplier.description}</p>
            </div>
            <div id="certs" class="tab-pane" style="display:none;">
                <p>ISO9001, CE, RoHS verified by SGS.</p>
            </div>
        </div>
    </div>
</div>
<%@ include file="/includes/footer.jsp" %>
