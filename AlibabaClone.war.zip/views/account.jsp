<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="/includes/header.jsp" %>

<c:if test="${empty sessionScope.loggedInUser}">
    <c:redirect url="/views/login.jsp"/>
</c:if>

<div class="container section-padding" style="margin-top:20px; background:#fff;">
    <div class="flex-row" style="gap:40px;">
        <!-- Left: Account Menu -->
        <div style="flex:2;">
            <div style="background:#f5f5f5; padding:20px; border-radius:8px;">
                <h3 style="margin-bottom:16px;"><i class="fa-regular fa-user"></i> My Account</h3>
                <ul style="list-style:none; padding:0;">
                    <li style="padding:12px 0; border-bottom:1px solid #ddd;">
                        <a href="#profile" onclick="showTab('profile')" style="text-decoration:none; color:#333; font-weight:500;">
                            <i class="fa-regular fa-id-card"></i> Profile
                        </a>
                    </li>
                    <li style="padding:12px 0; border-bottom:1px solid #ddd;">
                        <a href="#orders" onclick="showTab('orders')" style="text-decoration:none; color:#333;">
                            <i class="fa-regular fa-box"></i> Orders
                        </a>
                    </li>
                    <li style="padding:12px 0; border-bottom:1px solid #ddd;">
                        <a href="#addresses" onclick="showTab('addresses')" style="text-decoration:none; color:#333;">
                            <i class="fa-regular fa-address-book"></i> Addresses
                        </a>
                    </li>
                    <li style="padding:12px 0; border-bottom:1px solid #ddd;">
                        <a href="#settings" onclick="showTab('settings')" style="text-decoration:none; color:#333;">
                            <i class="fa-solid fa-gear"></i> Settings
                        </a>
                    </li>
                    <li style="padding:12px 0;">
                        <a href="${pageContext.request.contextPath}/user?action=logout" style="text-decoration:none; color:#FF6A00; font-weight:500;">
                            <i class="fa-solid fa-sign-out-alt"></i> Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Right: Account Content -->
        <div style="flex:5;">
            <!-- Profile Tab -->
            <div id="profile" class="account-tab" style="display:block;">
                <h2>My Profile</h2>
                <div style="background:#f9f9f9; padding:20px; border-radius:8px; margin-top:16px;">
                    <div class="flex-row" style="margin-bottom:16px;">
                        <div style="flex:1;">
                            <label style="display:block; font-size:12px; color:#888; margin-bottom:4px;">Full Name</label>
                            <input type="text" value="${sessionScope.loggedInUser.username}" readonly style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; background:#fff;">
                        </div>
                        <div style="flex:1; margin-left:16px;">
                            <label style="display:block; font-size:12px; color:#888; margin-bottom:4px;">Email</label>
                            <input type="email" value="${sessionScope.loggedInUser.email}" readonly style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; background:#fff;">
                        </div>
                    </div>
                    <div class="flex-row" style="margin-bottom:16px;">
                        <div style="flex:1;">
                            <label style="display:block; font-size:12px; color:#888; margin-bottom:4px;">Role</label>
                            <input type="text" value="${sessionScope.loggedInUser.role}" readonly style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; background:#fff; text-transform:capitalize;">
                        </div>
                        <div style="flex:1; margin-left:16px;">
                            <label style="display:block; font-size:12px; color:#888; margin-bottom:4px;">Country</label>
                            <input type="text" value="${sessionScope.loggedInUser.countryCode}" readonly style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; background:#fff;">
                        </div>
                    </div>
                    <div style="margin-bottom:16px;">
                        <label style="display:block; font-size:12px; color:#888; margin-bottom:4px;">Member Since</label>
                        <input type="text" value="${sessionScope.loggedInUser.createdAt}" readonly style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; background:#fff;">
                    </div>
                    <button class="btn-primary" onclick="alert('Feature coming soon')" style="padding:10px 24px;">Edit Profile</button>
                </div>
            </div>

            <!-- Orders Tab -->
            <div id="orders" class="account-tab" style="display:none;">
                <h2>My Orders</h2>
                <c:choose>
                    <c:when test="${empty sessionScope.orderHistory}">
                        <div style="background:#f9f9f9; padding:20px; border-radius:8px; margin-top:16px; text-align:center; color:#888;">
                            <p><i class="fa-regular fa-inbox" style="font-size:32px; margin-bottom:8px; display:block;"></i></p>
                            <p>You have no orders yet.</p>
                            <a href="${pageContext.request.contextPath}/" class="text-accent" style="margin-top:12px; display:inline-block;">Continue Shopping</a>
                        </div>
                    </c:when>
                    <c:otherwise>
                        <div style="margin-top:16px; display:flex; flex-direction:column; gap:16px;">
                            <c:forEach var="order" items="${sessionScope.orderHistory}">
                                <div style="background:#f9f9f9; padding:20px; border-radius:8px;">
                                    <div class="flex-row flex-space-between" style="margin-bottom:12px;">
                                        <div>
                                            <div style="font-weight:600;">Order ${order.orderNumber}</div>
                                            <div style="color:#777; font-size:12px;">Placed on ${order.placedAt}</div>
                                        </div>
                                        <div style="font-weight:700; color:#FF6A00;">$${order.total}</div>
                                    </div>
                                    <div style="border-top:1px solid #e0e0e0; padding-top:12px;">
                                        <div style="font-size:12px; color:#666; margin-bottom:8px;">Items (${fn:length(order.items)})</div>
                                        <c:forEach var="item" items="${order.items}">
                                            <div class="flex-row flex-space-between" style="margin-bottom:6px;">
                                                <span>${item.product.title} × ${item.quantity}</span>
                                                <span>$${item.product.priceMin * item.quantity}</span>
                                            </div>
                                        </c:forEach>
                                    </div>
                                </div>
                            </c:forEach>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>

            <!-- Addresses Tab -->
            <div id="addresses" class="account-tab" style="display:none;">
                <h2>My Addresses</h2>
                <div style="background:#f9f9f9; padding:20px; border-radius:8px; margin-top:16px;">
                    <div style="font-weight:600;">Saved addresses</div>
                    <div id="accountAddressList" style="margin-top:12px; display:grid; gap:12px;"></div>
                </div>
                <div style="background:#f9f9f9; padding:20px; border-radius:8px; margin-top:16px;">
                    <div style="font-weight:600;">Add new address</div>
                    <div style="color:#777; margin-top:4px;">Saved locally in this browser (not in the database).</div>
                    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:12px; margin-top:12px;">
                        <input type="text" id="accountAddressName" placeholder="Full name *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        <input type="text" id="accountAddressLine1" placeholder="Address line 1 *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        <input type="text" id="accountAddressLine2" placeholder="Address line 2" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        <input type="text" id="accountAddressCity" placeholder="City *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        <input type="text" id="accountAddressState" placeholder="State/Province *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        <input type="text" id="accountAddressZip" placeholder="Postal code *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        <input type="text" id="accountAddressCountry" placeholder="Country *" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                        <input type="text" id="accountAddressPhone" placeholder="Phone" style="width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:6px;">
                    </div>
                    <div style="margin-top:12px; display:flex; gap:12px; flex-wrap:wrap;">
                        <button type="button" id="saveAccountAddressBtn" class="btn-primary" style="padding:10px 24px;">Save Address</button>
                    </div>
                    <div id="accountAddressError" style="display:none; color:#c00; margin-top:8px;">Please fill in the required fields to save this address.</div>
                </div>
            </div>

            <!-- Settings Tab -->
            <div id="settings" class="account-tab" style="display:none;">
                <h2>Account Settings</h2>
                <div style="background:#f9f9f9; padding:20px; border-radius:8px; margin-top:16px;">
                    <div style="margin-bottom:20px;">
                        <h3 style="font-size:14px; margin-bottom:12px;">Change Password</h3>
                        <input type="password" placeholder="Current Password" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; margin-bottom:8px;">
                        <input type="password" placeholder="New Password" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; margin-bottom:8px;">
                        <input type="password" placeholder="Confirm New Password" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px; margin-bottom:12px;">
                        <button class="btn-primary" onclick="alert('Feature coming soon')" style="padding:10px 24px;">Update Password</button>
                    </div>
                    <div style="border-top:1px solid #ddd; padding-top:20px;">
                        <h3 style="font-size:14px; margin-bottom:12px; color:#d32f2f;">Danger Zone</h3>
                        <button style="padding:10px 24px; background:#d32f2f; color:#fff; border:none; border-radius:4px; cursor:pointer; font-weight:500;" onclick="if(confirm('Are you sure you want to delete your account? This cannot be undone.')) { alert('Feature coming soon'); }">Delete Account</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var addressStorageKey = "ag_address_book";
    var addressHiddenKey = "ag_address_hidden";
    var defaultAddresses = [
        {
            id: "addr-default-1",
            name: "Aisha Khan",
            line1: "23 Lake View Road",
            line2: "",
            city: "Colombo 03",
            state: "Western",
            zip: "00300",
            country: "Sri Lanka",
            phone: "+94 77 123 4567"
        },
        {
            id: "addr-default-2",
            name: "Naveen Perera",
            line1: "88 Market Street",
            line2: "",
            city: "Kandy",
            state: "Central",
            zip: "20000",
            country: "Sri Lanka",
            phone: "+94 71 555 2211"
        },
        {
            id: "addr-default-3",
            name: "Imani Silva",
            line1: "12 Palm Grove",
            line2: "",
            city: "Galle",
            state: "Southern",
            zip: "80000",
            country: "Sri Lanka",
            phone: "+94 76 222 3311"
        }
    ];

    function showTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('.account-tab').forEach(tab => {
            tab.style.display = 'none';
        });
        // Show selected tab
        document.getElementById(tabName).style.display = 'block';
    }

    function escapeHtml(text) {
        var map = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };
        return String(text).replace(/[&<>"']/g, function(match) {
            return map[match];
        });
    }

    function loadSavedAddresses() {
        try {
            var raw = localStorage.getItem(addressStorageKey);
            var parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (err) {
            return [];
        }
    }

    function loadHiddenDefaults() {
        try {
            var raw = localStorage.getItem(addressHiddenKey);
            var parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (err) {
            return [];
        }
    }

    function saveAddresses(addresses) {
        try {
            localStorage.setItem(addressStorageKey, JSON.stringify(addresses));
        } catch (err) {
            return;
        }
    }

    function saveHiddenDefaults(hiddenIds) {
        try {
            localStorage.setItem(addressHiddenKey, JSON.stringify(hiddenIds));
        } catch (err) {
            return;
        }
    }

    function createAddressCard(address) {
        var card = document.createElement("div");
        card.style.cssText = "background:#fff; padding:12px; border-radius:8px; border:1px solid #eee;";
        var header = document.createElement("div");
        header.style.cssText = "display:flex; justify-content:space-between; align-items:center; gap:12px;";
        var nameEl = document.createElement("div");
        nameEl.style.fontWeight = "600";
        nameEl.textContent = address.name;
        header.appendChild(nameEl);

        var deleteBtn = document.createElement("button");
        deleteBtn.type = "button";
        deleteBtn.textContent = "Delete";
        deleteBtn.style.cssText = "padding:6px 12px; border:1px solid #ffbdbd; background:#fff0f0; color:#c00; border-radius:6px; cursor:pointer;";
        deleteBtn.addEventListener("click", function() {
            deleteAddress(address);
        });
        header.appendChild(deleteBtn);

        var line1El = document.createElement("div");
        line1El.style.color = "#555";
        line1El.textContent = address.line1;

        card.appendChild(header);
        card.appendChild(line1El);

        if (address.line2) {
            var line2El = document.createElement("div");
            line2El.style.color = "#555";
            line2El.textContent = address.line2;
            card.appendChild(line2El);
        }

        var cityEl = document.createElement("div");
        cityEl.style.color = "#555";
        cityEl.textContent = address.city + ", " + address.state + " " + address.zip;
        card.appendChild(cityEl);

        var countryEl = document.createElement("div");
        countryEl.style.color = "#555";
        countryEl.textContent = address.country;
        card.appendChild(countryEl);

        if (address.phone) {
            var phoneEl = document.createElement("div");
            phoneEl.style.color = "#777";
            phoneEl.textContent = address.phone;
            card.appendChild(phoneEl);
        }
        return card;
    }

    function deleteAddress(address) {
        if (address.isDefault) {
            var hidden = loadHiddenDefaults();
            if (hidden.indexOf(address.id) === -1) {
                hidden.push(address.id);
                saveHiddenDefaults(hidden);
            }
        } else {
            var saved = loadSavedAddresses();
            var updated = saved.filter(function(item) {
                return item.id !== address.id;
            });
            saveAddresses(updated);
        }
        renderAccountAddresses();
    }

    function renderAccountAddresses() {
        var list = document.getElementById("accountAddressList");
        if (!list) {
            return;
        }
        list.innerHTML = "";
        var saved = loadSavedAddresses();
        var hidden = loadHiddenDefaults();
        var combined = [];

        defaultAddresses.forEach(function(address) {
            if (hidden.indexOf(address.id) === -1) {
                combined.push({
                    id: address.id,
                    name: address.name,
                    line1: address.line1,
                    line2: address.line2,
                    city: address.city,
                    state: address.state,
                    zip: address.zip,
                    country: address.country,
                    phone: address.phone,
                    isDefault: true
                });
            }
        });

        saved.forEach(function(address) {
            combined.push({
                id: address.id,
                name: address.name,
                line1: address.line1,
                line2: address.line2,
                city: address.city,
                state: address.state,
                zip: address.zip,
                country: address.country,
                phone: address.phone,
                isDefault: false
            });
        });

        combined.forEach(function(address) {
            list.appendChild(createAddressCard(address));
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        const hash = window.location.hash.replace('#', '');
        if (hash) {
            showTab(hash);
        }

        renderAccountAddresses();

        var saveBtn = document.getElementById("saveAccountAddressBtn");
        var error = document.getElementById("accountAddressError");
        if (saveBtn) {
            saveBtn.addEventListener("click", function() {
                var name = document.getElementById("accountAddressName").value.trim();
                var line1 = document.getElementById("accountAddressLine1").value.trim();
                var line2 = document.getElementById("accountAddressLine2").value.trim();
                var city = document.getElementById("accountAddressCity").value.trim();
                var state = document.getElementById("accountAddressState").value.trim();
                var zip = document.getElementById("accountAddressZip").value.trim();
                var country = document.getElementById("accountAddressCountry").value.trim();
                var phone = document.getElementById("accountAddressPhone").value.trim();

                if (!name || !line1 || !city || !state || !zip || !country) {
                    if (error) {
                        error.style.display = "block";
                    }
                    return;
                }

                if (error) {
                    error.style.display = "none";
                }

                var saved = loadSavedAddresses();
                saved.push({
                    id: "addr-saved-" + Date.now(),
                    name: name,
                    line1: line1,
                    line2: line2,
                    city: city,
                    state: state,
                    zip: zip,
                    country: country,
                    phone: phone
                });
                saveAddresses(saved);
                renderAccountAddresses();

                document.getElementById("accountAddressName").value = "";
                document.getElementById("accountAddressLine1").value = "";
                document.getElementById("accountAddressLine2").value = "";
                document.getElementById("accountAddressCity").value = "";
                document.getElementById("accountAddressState").value = "";
                document.getElementById("accountAddressZip").value = "";
                document.getElementById("accountAddressCountry").value = "";
                document.getElementById("accountAddressPhone").value = "";
            });
        }
    });
</script>

<%@ include file="/includes/footer.jsp" %>
